const { model, Schema } = require('mongoose');
const backupSchema = new Schema({
  guildId: String,
  backupData: Object,
});

const Backup = model('Backup', backupSchema);
