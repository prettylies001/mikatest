const { model, Schema } = require("mongoose");
const reminderSchema = new Schema({
  user: { type: String, required: true },
  message: { type: String, required: true },
  timestamp: { type: Date, required: true },
});
module.exports = model("Reminder", reminderSchema);

