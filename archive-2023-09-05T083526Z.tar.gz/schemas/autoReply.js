const {model , Schema} = require("mongoose");



let autoReply = new Schema({

  Guild: String,

  Content: String,

  Reply: String



})



module.exports = model("autoReply", autoReply);