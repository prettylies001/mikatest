const { model, Schema } = require('mongoose');
const BoostSchema = new Schema({
  guildId: { type: String, required: true },
  channelId: { type: String, required: true },
  message: {
    imageUrl: String,
    description: String,
    // Add any other fields you want to include here
  },
});


module.exports = model('Boost', BoostSchema);