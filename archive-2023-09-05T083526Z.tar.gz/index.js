const { Client, GatewayIntentBits, Partials, Collection ,ActivityType,EmbedBuilder,MessageManager, ChatInputCommandInteraction, SlashCommandBuilder } = require("discord.js")

require('dotenv').config();
const { Guilds, GuildMembers, GuildMessages, GuildPresences } = GatewayIntentBits;

const { User, Message, GuildMember, ThreadMember } = Partials;


const { loadEvents } = require("./Handlers/eventHandler");

const client = new Client({ 
  intents: [GatewayIntentBits.Guilds,GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
GatewayIntentBits.GuildIntegrations,
 GatewayIntentBits.GuildMessageReactions,     GatewayIntentBits.GuildMessages,  GatewayIntentBits.GuildPresences,GatewayIntentBits.GuildVoiceStates,
           ],
partials: [User, Message, GuildMember, ThreadMember]});

client.events = new Collection()
client.commands = new Collection()
client.voiceGenerator = new Collection();
loadEvents(client);
////
/* Giveaway System */

require('./system/GiveawaySystem')(client);
///anticrash
require("./Handlers/Anticrash.js")(client);
///sticky
client.on("messageCreate", message => {
const stickySchema = require('./schemas/stickySchema');



stickySchema.findOne({ ChannelID: message.channel.id }, async(err, data) => {

    if(err) console.log(`[${chalk.red(`SCHEMA-ERROR`)}]${chalk.white(" - ")}${chalk.red(`An error occured while getting the data from stickySchema: ${err}`)}`);

    if(!data) {

                return;

    }

    let channel = data.ChannelID;

    let cachedChannel = client.channels.cache.get(channel)

    const sticky_embed = new EmbedBuilder()

    .setDescription(data.Message)

    .setColor('#2f3136')


    .setFooter({ text: "This is a sticky message"})

    if(message.channel.id == channel) {

        data.CurrentCount += 1

        data.save()

        if(data.CurrentCount > data.MaxCount) {

            try {

                await client.channels.cache.get(channel).messages.fetch(data.LastMessageID).then(async(m) => {

                    await m.delete()

                })

                let newstickymessage = await cachedChannel.send({ embeds: [sticky_embed] })

                data.LastMessageID = newstickymessage.id;

                data.CurrentCount = 0;

                data.save()

            } catch {

                return;

            }

        }

    }

})

  
})

 /////

       // Listen for the 'guildMemberBoost' event
 




        
  // 

  


    
      
      

 
  
      

      // 


      
  


 

    



  
 


// Made heh
client.on("messageCreate", message => {

  if (message.content === "<@1071310837895139362>") {

    const embed = new EmbedBuilder()

     
.setAuthor({ name: 'Hewwo', iconURL: "https://64.media.tumblr.com/2ae8c5fd92050bdca9e8e3f4d2b12747/674eb56437e071f8-7a/s640x960/646323e6786ec10f25ea36c65de57e4c155fecb0.gif"})
    .setDescription("Hello hello i am Mika  Type </help:1021791374145769558> to view my commands")    .setImage("https://media.tenor.com/6Gr-6QEvE7EAAAAd/school-live-cute.gif")
  .setColor('#2f3136')
    message.reply({ embeds: [embed]})

  }

})
///

///


client.login(process.env.token)
    