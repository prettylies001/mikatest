const { loadCommands } = require("../../Handlers/commandHandler")
const mongoose = require('mongoose');
const mongodb = require('dotenv').config();
const {ActivityType} = require('discord.js')
module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        await
        mongoose.set('strictQuery', true);
        mongoose.connect(process.env.mongodb || '', {
            keepAlive:true,
        })
        
        if (mongoose.connect) {
            
            console.log('MongoDB connection successful')
        }
      
    console.log(`The client is now ready, and logged in as ${client.user.username}`)
   client.user.setPresence({

  activities: [{ name: `something`, type: ActivityType.Streaming, url: `https://www.twitch.tv/zajef77` }],

  status: 'dnd',

});
    
    loadCommands(client);
  }
}