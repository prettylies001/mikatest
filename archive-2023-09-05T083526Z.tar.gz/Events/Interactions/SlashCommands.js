const { ChatInputCommandInteraction } = require("discord.js");

module.exports = {
  name: "interactionCreate",
  /**
  *
  * @param {ChatInputCommadInteraction} interaction
*/
  execute(interaction, client) {
    if(!interaction.isChatInputCommand()) return;

    const command = client.commands.get(interaction.commandName);
    if(!command) 
      return interaction.reply({
        content: "This command is outdated.",
      ephemeral: true
      });
    
    if(command.devonly && interaction.user.id !== "1059116301831909426")
      return interaction.reply({
        content: "Sorry only the developer can use this command.",
  ephemeral: true
      });

    command.execute(interaction, client)
  }
}