const {EmbedBuilder} = require("discord.js");
const Boost = require('../../schemas/BoostSchema');
module.exports = {

  name: 'guildBoostLevelUp',

  async execute(guild, member, boostLevel) {

    

    const boost = await Boost.findOne({ guildId: guild.id });

    if (!boost) return;

    const boostLeveling = guild.premiumTier;
const boostCount = guild.premiumSubscriptionCount;
const boostText = boostLevel === 0 ? "Not Boosted" : `Boost Level ${boostLeveling} | ${boostCount} Boosts`;


    const embed = new EmbedBuilder()
      .setTitle(`Thank you ${member.user.username} for boosting the ${guild.name}!`)
      .setDescription(`${guild.name} currently has ${boostText}!

Enjoy your special perks`)
      .setColor('#ffc0cb')
    .setImage('https://media.tenor.com/Jk4NHfdaKu0AAAAC/anime-studio-ghibli.gif')
      .setTimestamp()
      .setFooter({text:`${member.user.username} Boosted the server :)`,iconURL: 'https://cdn3.emoji.gg/emojis/6494-discord-boost.gif'});

    

    // Add the image to the message if provided

   if (boost.message.imageUrl) {

      embed.setImage(boost.message.imageUrl);

    }

    // Add the description to the message if provided

   if (boost.message.description) {

      embed.setDescription(boost.message.description);

    }

    // Send the message to the configured channel

    const channel = guild.channels.cache.get(boost.channelId);

    if (!channel) return;

    channel.send({content:`Thank you ${member.user} ^^`, embeds: [embed] });

  },

};
