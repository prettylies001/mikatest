const autoReply = require('../../schemas/autoReply');
module.exports = {

  name: 'messageCreate',

  async execute(message) {

    if (message.author.bot) return;

        const triggers = await autoReply.find({Guild: message.guild.id});

        const content = message.content.toLowerCase();

     for (const trigger of triggers) {
        if (content === (trigger.Content.toLowerCase())) {

            message.channel.send(trigger.Reply);
            break;
        }
    }
}
    }
