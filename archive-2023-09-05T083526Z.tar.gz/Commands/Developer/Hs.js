// backup.js
const { SlashCommandBuilder } = require('@discordjs/builders');
const { Client, ActionRowBuilder, ButtonBuilder } = require('discord.js');
const mongoose = require('mongoose');

// Create a Mongoose schema for backups
const backupSchema = new mongoose.Schema({
  guildId: String,
  backupData: Object,
});

const Backup = mongoose.model('Backup', backupSchema);

module.exports = {
  data: new SlashCommandBuilder()
    .setName('backup')
    .setDescription('Create or restore a backup of the server')
    .addSubcommand((subcommand) =>
      subcommand
        .setName('create')
        .setDescription('Create a backup of the server')
    )
    .addSubcommand((subcommand) =>
      subcommand
        .setName('restore')
        .setDescription('Restore a backup to the server')
        .addStringOption((option) =>
          option
            .setName('backup_id')
            .setDescription('The ID of the backup to restore')
            .setRequired(true)
        )
    )
    .addSubcommand((subcommand) =>
      subcommand
        .setName('backedservers')
        .setDescription('List available backups for restoration')
    ),

  async execute(interaction) {
    const subcommand = interaction.options.getSubcommand();

    if (subcommand === 'create') {
      await createBackup(interaction);
    } else if (subcommand === 'restore') {
      await restoreBackup(interaction);
    } else if (subcommand === 'backedservers') {
      await listBackups(interaction);
    }
  },
};

// Function to create a backup
async function createBackup(interaction) {
  const guild = interaction.guild;
  const backupData = {
    roles: guild.roles.cache.toJSON(),
    channels: guild.channels.cache.toJSON(),
    // Add more data you want to backup
  };

  const newBackup = new Backup({
    guildId: guild.id,
    backupData,
  });

  try {
    await newBackup.save();
    await interaction.reply('Backup created successfully!');
  } catch (error) {
    console.error(error);
    await interaction.reply('Failed to create a backup.');
  }
}

// Function to restore a backup
async function restoreBackup(interaction) {
  const guild = interaction.guild;
  const backupId = interaction.options.getString('backup_id');

  try {
    const backup = await Backup.findOne({ guildId: guild.id, _id: backupId });

    if (!backup) {
      await interaction.reply('Backup not found.');
      return;
    }

    // Implement your restoration logic here
    // Example: Apply backupData to the guild

    await interaction.reply('Backup restored successfully!');
  } catch (error) {
    console.error(error);
    await interaction.reply('Failed to restore the backup.');
  }
}

// Function to list available backups
async function listBackups(interaction) {
  const guild = interaction.guild;

  try {
    const backups = await Backup.find({ guildId: guild.id });

    if (backups.length === 0) {
      await interaction.reply('No backups found.');
      return;
    }

    // Create a message with buttons for each backup
    const buttons = backups.map((backup) => {
      return new MessageButton()
        .setCustomId(`restore_${backup._id}`)
        .setLabel(`Restore Backup ${backup._id}`)
        .setStyle('PRIMARY');
    });

    const row = new MessageActionRow().addComponents(...buttons);

    await interaction.reply({
      content: 'Choose a backup to restore:',
      components: [row],
    });
  } catch (error) {
    console.error(error);
    await interaction.reply('Failed to list backups.');
  }
}
