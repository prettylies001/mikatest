const { ChatInputCommandInteraction, SlashCommandBuilder, PermissionFlagsBits, Client, EmbedBuilder} = require("discord.js")
const { loadCommands } = require("../../Handlers/commandHandler")
const { loadEvents } = require("../../Handlers/eventHandler")

module.exports = {
  developer: true,
  data: new SlashCommandBuilder()
  .setName("reload")
  .setDescription("Restarts the bot [Bot Developer Only!]")
  
  .addSubcommand((options) => options
                .setName("events")
                .setDescription("Restarts the bot events"))
  .addSubcommand((options) => options
                .setName("commands")
                .setDescription("Restarts the bot commands.")),
  /**
  *
  * @param {ChatInputCommandInteraction} interaction
* @param {Client} client
*/
  execute(interaction, client) {
      if (!['1059116301831909426', '1009220856188240012'].includes(interaction.user.id)) return interaction.reply({ content: `you can't use this command only the the dev can use it`, ephemeral: true })
    const subCommand = interaction.options.getSubcommand();

  switch(subCommand) {
      case "events" : {
        for( const [key, value] of client.events )
          client.removeListener(`${key}`, value, true);
        loadEvents(client);
        const embed = new EmbedBuilder()
        .setTitle("Reload")
        .setDescription("Successfully Reloaded/Restarted the bot events")
        interaction.reply({ embeds: [embed], ephemeral: true})
      }
      break;
    case "commands" : {
      loadCommands(client);
      const embed = new EmbedBuilder()
      .setTitle("Reload")
      .setDescription("Successfully Reloaded/Restarted the bot commands.")
      interaction.reply({ embeds: [embed], ephemeral: true})
    }
      break;
  }
  }
}