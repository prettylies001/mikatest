const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('roleinfo')
    .setDescription('Get advanced information about a role')
    .addRoleOption(option => option.setName('role').setDescription('The role to get information about')),
  async execute(interaction) {
    const role = interaction.options.getRole('role');

    if (!role) {
      return interaction.reply('Please provide a valid role.');
    }

    const membersWithRole = interaction.guild.members.cache.filter(member => member.roles.cache.has(role.id));

    const roleInfo = {
      name: role.name,
      id: role.id,
      color: role.hexColor,
      mentionable: role.mentionable,
      hoisted: role.hoist,
      createdAt: role.createdAt,
      permissions: role.permissions.toArray(),
      memberCount: membersWithRole.size,
      position: role.rawPosition,
    };

    const permissionNames = role.permissions.toArray().map(permission => `\`${permission}\``).join(', ');

    interaction.reply({
      embeds: [{
        title: `Role Information: ${role.name}`,
        color: parseInt(role.hexColor.replace(/^#/, ''), 16),
        fields: [
          { name: 'ID', value: role.id },
          { name: 'Color', value: role.hexColor.toUpperCase(), inline: true },
          { name: 'Mentionable', value: role.mentionable ? 'Yes' : 'No', inline: true },
          { name: 'Hoisted', value: role.hoist ? 'Yes' : 'No', inline: true },
          { name: 'Created At', value: role.createdAt.toUTCString() },
          { name: 'Permissions', value: permissionNames || 'No permissions' },
          { name: 'Members with this role', value: roleInfo.memberCount.toString() },
          { name: 'Position', value: roleInfo.position.toString() },
        ],
      }],
    });
  },
};
