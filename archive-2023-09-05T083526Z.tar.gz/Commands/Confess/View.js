const { SlashCommandBuilder, PermissionsBitField, EmbedBuilder, ChannelType } = require('discord.js');

const Reminder = require('../../schemas/Reminder');



module.exports = {
  data: new SlashCommandBuilder()
    .setName('reminderlist')
    .setDescription('View your active reminders'),

  async execute(interaction) {
    const user = interaction.user.id;

    try {
      const reminders = await Reminder.find({ user: user, timestamp: { $gte: new Date() } });
      if (reminders.length === 0) {
        const embed = new EmbedBuilder()
          .setColor('#2f3136')
          .setTitle('No active reminders')
          .setDescription('You have no active reminders');
        interaction.reply({ embeds: [embed], ephemeral:true });
        return;
      }
      const embed = new EmbedBuilder()
        .setColor('#2f3136')
        .setTitle(`You have ${reminders.length} active reminders`)
        .setDescription('Here are your active reminders:');
      reminders.forEach(reminder => {
        const remainingTime = Math.floor((reminder.timestamp - Date.now()) / 1000); // Calculate remaining time in seconds
        const days = Math.floor(remainingTime / (24 * 60 * 60));
        const hours = Math.floor((remainingTime % (24 * 60 * 60)) / (60 * 60));
        const minutes = Math.floor((remainingTime % (60 * 60)) / 60);
        const seconds = Math.floor(remainingTime % 60);

        let remainingTimeString = '';
        if (days > 0) {
          remainingTimeString += `${days} day${days > 1 ? 's' : ''} `;
        }
        if (hours > 0) {
          remainingTimeString += `${hours} hour${hours > 1 ? 's' : ''} `;
        }
        if (minutes > 0) {
          remainingTimeString += `${minutes} minute${minutes > 1 ? 's' : ''} `;
        }
        if (remainingTimeString === '' || seconds > 0) {
          remainingTimeString += `${seconds} second${seconds > 1 ? 's' : ''}`;
        }

        embed.addFields({name:`Reminder ID ${reminder._id}`, value:`${reminder.message}\nTime remaining: ${remainingTimeString}`});
      });
      interaction.reply({ embeds: [embed], ephemeral:true });
    } catch (error) {
      console.error(error);
      const embed = new EmbedBuilder()
        .setColor('Red')
        .setTitle('Error retrieving reminders 😭')
        .setDescription('An error occurred while retrieving your reminders');
      interaction.reply({ embeds: [embed] });
    }
  },
};

