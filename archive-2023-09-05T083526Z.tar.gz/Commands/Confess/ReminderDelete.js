const { SlashCommandBuilder, PermissionsBitField, EmbedBuilder, ChannelType } = require('discord.js');

const Reminder = require('../../schemas/Reminder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('reminderdelete')
    .setDescription('Delete an active reminder')
    .addStringOption(option =>
      option.setName('id')
      .setDescription('The ID of the reminder to be deleted')
      .setRequired(true)
    ),

  async execute(interaction) {
    const id = interaction.options.getString('id');

    try {
      const reminder = await Reminder.findByIdAndDelete(id);
      if (!reminder) {
        const embed = new EmbedBuilder()
          .setColor('Red')
          .setTitle('Invalid reminder ID')
          .setDescription('The specified ID does not match an active reminder');
        interaction.reply({ embeds: [embed] });
        return;
      }
      const embed = new EmbedBuilder()
        .setColor('Green')
        .setTitle('Reminder deleted')
        .setDescription(`The reminder "${reminder.message}" has been successfully deleted`);
      interaction.reply({ embeds: [embed] ,ephemeral:true});
    } catch (error) {
      console.error(error);
      const embed = new EmbedBuilder()
        .setColor('Red')
        .setTitle('Error deleting reminder 😭')
        .setDescription('An error occurred while deleting the reminder');
      interaction.reply({ embeds: [embed], ephemeral:true});
    }
  },
};
