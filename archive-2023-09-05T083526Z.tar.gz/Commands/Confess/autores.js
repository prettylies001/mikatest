const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder } = require("discord.js");
const autoReply = require('../../schemas/autoReply');

module.exports = {
  data: new SlashCommandBuilder()
    .setName("autoreply")
    .setDescription("test!")
    .addSubcommand(command =>
      command
        .setName("set")
        .setDescription("Tạo một tin nhắn auto reply")
        .addStringOption(option =>
          option.setName("trigger").setDescription("Trigger của tin nhắn").setRequired(true)
        )
        .addStringOption(option =>
          option.setName("reply").setDescription("Reply của tin nhắn").setRequired(true)
        )
    )
    .addSubcommand(command =>
      command
        .setName("delete")
        .setDescription("Xóa tin nhắn auto reply")
        .addStringOption(option =>
          option.setName("message").setDescription("Trigger của tin nhắn").setRequired(true)
        )
    )
    .addSubcommand(command =>
      command
        .setName("list")
        .setDescription("Danh sách tin nhắn auto reply trong Server")
    ),

  async execute(interaction) {
    const { options } = interaction;
    const sub = options.getSubcommand();

    // Permissions
    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
      return interaction.reply({
        content: "Bạn không quyền `Manage Messages` để dùng lệnh.",
        ephemeral: true,
      });
    }

    switch (sub) {
      case 'set':
        const trigger = options.getString('trigger').toLowerCase(); // Convert trigger to lowercase
        const reply = options.getString('reply');

        const data = await autoReply.findOne({
          Guild: interaction.guild.id,
          Content: trigger
        });

        if (data) return interaction.reply("Đã có trigger này rồi!");

        await autoReply.create({
          Guild: interaction.guild.id,
          Content: trigger,
          Reply: reply
        });

        await interaction.reply({
          embeds: [new EmbedBuilder()
          .setColor('#f1e78c')
           .setTitle("Đã Tạo Thành Công")
          .addFields({name: "Trigger", value: trigger,inline: false})
          .addFields({name: "Reply", value: `\`\`\`${reply}\`\`\``})
          .setFooter({text: "Xuân Hạ Thu Đông"})
          .setTimestamp()]
        });
        break;

      case 'delete':
        const message = options.getString('message').toLowerCase(); // Convert message to lowercase

        const exData = await autoReply.findOne({
          Guild: interaction.guild.id,
          Content: message
        });

        if (!exData) return interaction.reply(`Không có trigger nào là ${message}`);


        await interaction.reply(`Đã xóa thành công trigger ${exData.Content}`);

        await autoReply.findOneAndDelete({
          Guild: interaction.guild.id,
          Content: message
        });
        
        break;

      case 'list':
        const entries = await autoReply.find({ Guild: interaction.guild.id });

        if (entries.length === 0) return interaction.reply({content: "Server chưa có tin nhắn autoreply nào cả", ephemeral: true});

        const embed = new EmbedBuilder()
          .setColor('#f1e78c') 
          .setTitle("Auto Reply List")
          .setFooter({text: "Xuân Hạ Thu Đông"})
          .setTimestamp()
          .setDescription(entries.map(entry => entry.Content).join("\n"));

        await interaction.reply({ embeds: [embed] });
        break;
    }
  }
};
