const { SlashCommandBuilder, PermissionsBitField, EmbedBuilder, ChannelType } = require('discord.js');

const Reminder = require('../../schemas/Reminder');


module.exports = {
  data: new SlashCommandBuilder()
    .setName('reminder')
    .setDescription('Set a reminder')
    .addStringOption(option =>
      option.setName('message')
      .setDescription('The message to be reminded of')
      .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('time')
      .setDescription('The time until the reminder should be sent (e.g. 5m, 1h, 2d)')
      .setRequired(true)
    ),

  async execute(interaction) {
    const message = interaction.options.getString('message');
    const timeString = interaction.options.getString('time');

    // Parse the time string
    const timeMatch = timeString.match(/^(\d+)([mhd])$/);
    if (!timeMatch) {
      const embed = new EmbedBuilder()
        .setColor('#2f3136')
        .setTitle('Error 😭')
        .setDescription('Invalid time format. Please use the format "[number][m/h/d]" (e.g. 5m, 1h, 2d)');
      interaction.reply({ embeds: [embed] });
      return;
    }

    const timeValue = parseInt(timeMatch[1]);
    const timeUnit = timeMatch[2];
    let timeMilliseconds;

    // Convert the time to milliseconds
    switch (timeUnit) {
      case 'm':
        timeMilliseconds = timeValue * 60000;
        break;
      case 'h':
        timeMilliseconds = timeValue * 3600000;
        break;
      case 'd':
        timeMilliseconds = timeValue * 86400000;
        break;
    }

    // Calculate the reminder timestamp
    const reminderTimestamp = new Date();
    reminderTimestamp.setTime(reminderTimestamp.getTime() + timeMilliseconds);

    // Save the reminder to the database
    const reminder = new Reminder({
      user: interaction.user.id,
      message,
      timestamp: reminderTimestamp,
    });
    await reminder.save();

    // Send confirmation message
    const embed = new EmbedBuilder()
      .setColor('#2f3136')
      .setTitle('Reminder set')
      .setDescription(`I will remind you about <a:whitebutterfly:1063093367891832933> "${message}" 
<a:bongocat:1063091349387214858> in ${timeValue} ${timeUnit}`);
    interaction.reply({ embeds: [embed] });

    // Schedule the reminder
    setTimeout(async () => {
      const reminders = await Reminder.find({ timestamp: { $lte: new Date() } });
      reminders.forEach(async reminder => {
        const user = interaction.client.users.cache.get(reminder.user);
        const embed = new EmbedBuilder()
          .setColor('#2f3136')
          .setTitle('Reminder')
          .setDescription(`You asked me to remind you about "${reminder.message}"`);
        user.send({ embeds: [embed] });
        await reminder.remove();
      });
    }, timeMilliseconds);
  },
};



