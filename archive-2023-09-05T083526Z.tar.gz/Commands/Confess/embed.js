const { EmbedBuilder, PermissionFlagsBits, ButtonBuilder, ButtonStyle, ActionRowBuilder, SlashCommandBuilder} = require("discord.js");
const embedSchema = require("../../schemas/embedSchema");

module.exports = {
  data: new SlashCommandBuilder()
    .setName('embed')
    .setDescription('make a embed'),
  async execute(interaction, client) {

    if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return interaction.reply({
          content: "you need admin perms for this.",
          ephemeral: true,
        });
      }

       const embed = new EmbedBuilder()
       .setTitle(`Embed Builder`)
       .setFooter({text: `^^`})
       .setTimestamp()
       
       const row1 = new ActionRowBuilder()
       .addComponents(
       new ButtonBuilder()
       .setLabel(`Title`)
       .setCustomId(`title`)
       .setStyle(ButtonStyle.Secondary),

       new ButtonBuilder()
       .setLabel(`Author`)
       .setCustomId(`author`)
       .setStyle(ButtonStyle.Secondary),

       new ButtonBuilder()
       .setLabel(`Description`)
       .setCustomId(`description`)
       .setStyle(ButtonStyle.Secondary),

       new ButtonBuilder()
       .setLabel(`Footer`)
       .setCustomId(`footer`)
       .setStyle(ButtonStyle.Secondary)
       )

       const row2 = new ActionRowBuilder()
       .addComponents(
       new ButtonBuilder()
       .setLabel(`Image`)
       .setCustomId(`image`)
       .setStyle(ButtonStyle.Secondary),

       new ButtonBuilder()
       .setLabel(`Thumbnail`)
       .setCustomId(`thumbnail`)
       .setStyle(ButtonStyle.Secondary),

       new ButtonBuilder()
       .setLabel(`TimeStamp`)
       .setCustomId(`timestamp`)
       .setStyle(ButtonStyle.Secondary)
       )

       const row3 = new ActionRowBuilder()
       .addComponents(
       new ButtonBuilder()
       .setLabel(`Send`)
       .setCustomId(`send`)
       .setStyle(ButtonStyle.Success),

       new ButtonBuilder()
       .setLabel(`Clear`)
       .setCustomId(`clear`)
       .setStyle(ButtonStyle.Primary),

       new ButtonBuilder()
       .setLabel(`Delete`)
       .setCustomId(`delete`)
       .setStyle(ButtonStyle.Danger)
       )

       const mess = await interaction.channel.send({embeds: [embed], components: [row1, row2, row3]});

       const datac = await embedSchema.create({MessageID: mess.id, ChannelID: interaction.channel.id, UserID: interaction.user.id, GuildID: interaction.guild.id});
       console.log(datac);

       interaction.reply({content:`Done`, ephemeral:true});

    },
  };
  