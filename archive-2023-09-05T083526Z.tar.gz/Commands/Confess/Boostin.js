const { SlashCommandBuilder } = require('@discordjs/builders');

module.exports = {

    data: new SlashCommandBuilder()
  .setName('boost-test')
  .setDescription('Simulates a boost event for testing purposes'),


  async execute(interaction,client) {
    // Emit a "guildBoostLevelUp" event with mock data
    interaction.client.emit('guildBoostLevelUp', interaction.guild, interaction.member, 2);

    // Send a confirmation message
    interaction.reply({
      content: 'Boost event emitted for testing purposes.',
    });
  },
};
