const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('gunfight')
        .setDescription('gunfight with your friend .')
        .addUserOption(option => option.setName('player').setDescription('Select a player to challenge').setRequired(true)),
    async execute(interaction) {
        
        const player = interaction.options.getUser('player');

       if (player.id === interaction.user.id) {

            

            return interaction.reply({content:'You cannot challenge yourself!', ephemeral: true});

        }
        await interaction.channel.send(`${player}, you have been challenged to a cowboy game by ${interaction.user}! Do you want to accept this challenge? Type "yes" or "no".`);

        // Await the selected player's response
        const filter = m => m.author.id === player.id && (m.content.toLowerCase() === 'yes' || m.content.toLowerCase() === 'no');
        const response = await interaction.channel.awaitMessages({ filter, max: 1, time: 15000 });

        if (!response.size) {
            
            return interaction.channel.send(`${player} did not respond in time. Maybe next time!`);
        }

        const answer = response.first().content.toLowerCase();
        if (answer === 'no') {
            // If the selected player declined the challenge
            return interaction.channel.send(`${player} declined the challenge. Maybe next time!`);
        } else if (answer !== 'yes') {
            // If the selected player responded with an invalid answer
            return interaction.channel.send('Invalid response. Maybe next time!');
        }

        // If the selected player accepted the challenge, start the game
        const words = ['shoot', 'draw', 'aim', 'reload', 'fire', 'bullets'];
        const word = words[Math.floor(Math.random() * words.length)];
        const delay = Math.floor(Math.random() * 5000) + 3000; 
        
        const readyEmbed = new EmbedBuilder()
  .setTitle('Get Ready!')

  .setDescription('The game will start at any moment.')
        .setImage('https://giffiles.alphacoders.com/102/102565.gif')
  .setColor('#ffa500');

await interaction.channel.send({ embeds: [readyEmbed] });

        
        await new Promise(resolve => setTimeout(resolve, delay));

        await interaction.channel.send(`The word is **${word}**! TYPE NOW!`);

       
        const winnerFilter = m => m.content.toLowerCase() === word.toLowerCase();
        const winner = await interaction.channel.awaitMessages({ filter: winnerFilter, max: 1, time: 15000 });

        if (!winner.size) {
           
            return interaction.channel.send(`No one typed the word in time. It's a tie!`);
        }

        const winnerUser = winner.first().author;

if (winnerUser.id === interaction.user.id) {

  const winnerEmbed = new EmbedBuilder()

    .setTitle('Congratulations!')
.setImage('https://media.tenor.com/oDedOU2hfZcAAAAC/anime-cowboybebop.gif')
    .setDescription(`${interaction.user} won the cowboy game against ${player}!`)

    .setColor('#00ff00');

  

  return interaction.channel.send({ embeds: [winnerEmbed] });

} else if (winnerUser.id === player.id) {

  const winnerEmbed = new EmbedBuilder()

    .setTitle('Congratulations!')
    .setImage('https://media.tenor.com/oDedOU2hfZcAAAAC/anime-cowboybebop.gif')
    .setDescription(`${player} won the cowboy game against ${interaction.user}!`)

    .setColor('#00ff00');

  return interaction.channel.send({ embeds: [winnerEmbed] });

}
        }
    }
