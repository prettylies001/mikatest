const { SlashCommandBuilder } = require('@discordjs/builders');
const { PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unban-all')
        .setDescription('Unban all members in the server'),

    async execute(interaction) {
        
        if (!['1059116301831909426', '1009220856188240012'].includes(interaction.user.id)) return interaction.reply({ content: `you can't use this command only the the dev can use it`, ephemeral: true })

        try {
            
            const bannedMembers = await interaction.guild.bans.fetch();
            
            await Promise.all(bannedMembers.map(member => {
                return interaction.guild.members.unban(member.user.id);
            }));
           
            return interaction.reply({ content: 'All members have been unbanned from the server.', ephemeral: true });
        } catch (error) {
            console.error(error);
            return interaction.reply({ content: 'An error occurred while unbanning members.', ephemeral: true });
        }
    },
};
