const { Client, SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } = require('discord.js')

module.exports = {
    data: new SlashCommandBuilder()
    .setName('yohelp')
    .setDescription('Need help, use this command!')
    .addStringOption(
        option =>
        option.setName('command')
        .setDescription('Get information about a command!')
    ),
    /**
     * 
     * @param {ChatInputCommandInteraction} interaction 
     * @param {Client} client 
     */
    async execute(interaction, client) {
        const { options, member } = interaction;

        const command = options.getString('command');

        const helpEmbed = new EmbedBuilder()
        .setTitle('📬 Need help? Here are all of my commands')
        .setDescription('Use ``/help`` followed by a command name to get more additional information on a command. For example ``/help afk``')
        .setColor('Red')
        .setFooter({ text: `Requested by ${member.user.tag}`, iconURL: member.user.displayAvatarURL() })
        .setTimestamp(Date.now())

        if(command) {
            if(client.commands.get(command)) {
                const commandInformation = client.commands.get(command)

                helpEmbed.setTitle(command).setDescription(commandInformation.data.description);
                return interaction.reply({ embeds: [helpEmbed], ephemeral: true })
            } else {
                return interaction.reply({ content: `\`\`${command}\`\` is not a valid command!`, ephemeral: true });
            }
        } else {
            const commandNames = client.commands.map(command => command.data.name).join(', ');
            
            helpEmbed.addFields({name:'Commands', value:commandNames});
            
            return interaction.reply({ embeds: [helpEmbed] })
        }
    }
}
