const { SlashCommandBuilder } = require('@discordjs/builders');

const { ActionRowBuilder, ButtonStyle, ButtonBuilder } = require('discord.js');

module.exports = {

    data: new SlashCommandBuilder()

        .setName('pollow')

        .setDescription('Create an advanced poll with Yes and No buttons.')

        .addStringOption(option =>

            option.setName('question')

                .setDescription('The question to ask in the poll.')

                .setRequired(true)

        ),

    async execute(interaction) {

        const question = interaction.options.getString('question');

        const pollEmbed = {

            

            title: 'Poll',

            author: {

                name: interaction.user.username,

                icon_url: interaction.user.avatarURL()

            },

            description: question,

            timestamp: new Date(),

            footer: {

                text: 'React to vote'

            }

        };

        const row = new ActionRowBuilder()

            .addComponents(

                new ButtonBuilder()

                    .setCustomId('yes')

                    .setLabel('Yes')

                    .setStyle(ButtonStyle.Primary)

                    .setEmoji('✅'),

                new ButtonBuilder()

                    .setCustomId('no')

                    .setLabel('No')

                  .setStyle(ButtonStyle.Danger)

                    .setEmoji('❌'),

            );

        const message = await interaction.reply({ embeds: [pollEmbed], components: [row], fetchReply: true });

        const filter = i => i.customId === 'yes' || i.customId === 'no';

        const collector = message.createMessageComponentCollector({ filter, time: 0 }); // 864000000 = will stay active for 30 days 

        let yesVotes = 0;

        let noVotes = 0;

        const votedUsers = new Set();

        collector.on('collect', i => {

            if (votedUsers.has(i.user.id)) {

                i.reply({ content: 'You have already voted.', ephemeral: true });

            } else {

                votedUsers.add(i.user.id);

                if (i.customId === 'yes') {

                    yesVotes++;

                } else if (i.customId === 'no') {

                    noVotes++;

                }

                const yesPercentage = ((yesVotes / (yesVotes + noVotes)) * 100).toFixed(2);

                const noPercentage = ((noVotes / (yesVotes + noVotes)) * 100).toFixed(2);

                const totalVotes = yesVotes + noVotes;

                pollEmbed.fields = [

                    { name: 'Yes', value: `${yesVotes} votes (${yesPercentage}%)`, inline: true },

                    { name: 'No', value: `${noVotes} votes (${noPercentage}%)`, inline: true },

                    { name: '\u200B', value: '\u200B', inline: false },

                    { name: 'Total Votes', value: `${totalVotes}`, inline: false }

                ];

                interaction.editReply({ embeds: [pollEmbed], components: [row] });

                i.reply({ content: 'Thanks for voting!', ephemeral: true });

            }

        })

        
}
        }