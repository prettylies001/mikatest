const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

const stickySchema = require('../../schemas/stickySchema');

module.exports = {

    data: new SlashCommandBuilder()

        .setName("unstick")

        .setDescription("Unsticks a sticky message from a channel.")

        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)

        .setDMPermission(false),

    async execute(i) {

        const data = await stickySchema.findOne({ ChannelID: i.channel.id })

        if(!data) {

            return await i.reply({ embeds: [new EmbedBuilder().setDescription("There is no sticky message in this channel.").setColor("Red")], ephemeral: true })

        } else {

            try {

               await i.client.channels.cache.get(data.ChannelID).messages.fetch(data.LastMessageID).then(async(m) => {

                    await m.delete()

                })

            } catch {

                return;

            }

        }

        stickySchema.deleteMany({ ChannelID: i.channel.id }, async(err, data) => {

            if(err) return console.log(err);

            return await i.reply({ embeds: [new EmbedBuilder().setDescription("Successfully deleted the sticky message in this channel.").setColor("Green")], ephemeral: true })

        })

    }

}