const { SlashCommandBuilder, Events, ModalBuilder, ActionRowBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder } = require('discord.js');

const { PermissionFlagsBits } = require('discord.js');



module.exports = {

    data: new SlashCommandBuilder()

    .setName('embedpost')

    .setDescription('Displays a form that allows you to send an embed to a given channel')

    .addChannelOption(option => option

        .setName('channel')

        .setDescription('The channel to send the message to')

        .setRequired(true)),

        

    async execute(interaction) {

        const channel = interaction.options.getChannel('channel');

            

        const modal = new ModalBuilder()

            .setCustomId('createEmbedModal')

            .setTitle('Create Embed');

        const createEmbedTitleInput = new TextInputBuilder()

            .setCustomId('createEmbedTitleInput')

            .setLabel('Title')

            .setStyle(TextInputStyle.Short);

        const createEmbedContentInput = new TextInputBuilder()

            .setCustomId('createEmbedContentInput')

            .setLabel('Embed content')

            .setStyle(TextInputStyle.Paragraph);

        const createEmbedColourInput = new TextInputBuilder()

            .setCustomId('createEmbedColourInput')

            .setLabel('Embed color, hexadecimal (no "#")')

            .setStyle(TextInputStyle.Short)

            .setRequired(false);

        const createEmbedImageInput = new TextInputBuilder()

            .setCustomId('createEmbedImageInput')

            .setLabel('Picture for the embed (URL)')

            .setStyle(TextInputStyle.Short)

            .setRequired(false);

        

        const createEmbedFooterInput = new TextInputBuilder()

            .setCustomId('createEmbedFooterInput')

            .setLabel('Embed footer')

            .setStyle(TextInputStyle.Short)

            .setRequired(false);

        const firstActionRow = new ActionRowBuilder().addComponents(createEmbedTitleInput);

        const secondActionRow = new ActionRowBuilder().addComponents(createEmbedContentInput);

        const thirdActionRow = new ActionRowBuilder().addComponents(createEmbedColourInput);

        const forthActionRow = new ActionRowBuilder().addComponents(createEmbedImageInput);

        const fifthActionRow = new ActionRowBuilder().addComponents(createEmbedFooterInput);

        

        modal.addComponents(firstActionRow, secondActionRow, thirdActionRow, forthActionRow, fifthActionRow);

        interaction.showModal(modal);

        interaction.client.once(Events.InteractionCreate, modalInteraction => {

            if (!modalInteraction.isModalSubmit()) return;

            

            if (channel.type !== 0){

                modalInteraction.reply('Wrong channel - you can only specify a text channel.');

                return;

            }

            try {

                const customEmbed = new EmbedBuilder()

                    .setAuthor({name: `✨`, iconURL: interaction.guild.iconURL()})

                   .setTitle(modalInteraction.fields.getTextInputValue('createEmbedTitleInput'))

                    .setDescription(modalInteraction.fields.getTextInputValue('createEmbedContentInput'))

                    .setColor(modalInteraction.fields.getTextInputValue('createEmbedColourInput') ? `0x${modalInteraction.fields.getTextInputValue('createEmbedColourInput')}` : '#2f3136')

                    .setImage(modalInteraction.fields.getTextInputValue('createEmbedImageInput') || null)

                    .setFooter({ text: modalInteraction.fields.getTextInputValue('createEmbedFooterInput') || 'Posted', iconURL: 'https://i.pinimg.com/originals/1d/26/a1/1d26a13e19a8c91b9fdb8af269008979.gif' })

                    .setTimestamp();

                channel.send({ embeds: [customEmbed] });

                modalInteraction.reply({ content: ` sent to ${channel}` ,ephemeral: true });

                // log(`<stworz-embeda> Użytkownik ${interaction.user.tag} stworzył embeda na kanale ${channel.name}.`);

            }

            catch (error) {

                console.log(error);

                modalInteraction.reply({content:'oops, Failed to create embed, most likely you made a mistake in the "Image" field (enter the exact URL to the image).',ephemeral: true});

            } 

        });

    }
    }
