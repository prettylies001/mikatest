const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

const stickySchema = require('../../schemas/stickySchema');

module.exports = {

    data: new SlashCommandBuilder()

        .setName("stick")

        .setDescription("Creates a sticky message in the current channel")

        .addStringOption(option => option.setName("message").setDescription("The message you want to stick to the chat.").setRequired(true))

        .addNumberOption(option => option.setName("count").setDescription("For how many messages should the bot wait until the sticky message gets sent again.").setRequired(false))

        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)

        .setDMPermission(false),

    async execute(i) {

        let string = i.options.getString("message")

        let amount = i.options.getNumber("count") || -1

        const sticky_embed = new EmbedBuilder()

        .setDescription(string)

        .setColor('#2f3136')

        .setFooter({ text: "This is a sticky message."})

        stickySchema.findOne({ ChannelID: i.channel.id }, async(err, data) => {

            if(err) return console.log(err)

            if(!data) {

                let msg = await i.channel.send({ embeds: [sticky_embed] })

                stickySchema.create({

                    ChannelID: i.channel.id,

                    Message: string,

                    MaxCount: amount,

                    LastMessageID: msg.id,

                })

                return await i.reply({ embeds: [new EmbedBuilder().setDescription(`Sticky message has been set up.`).setColor("Green")], ephemeral: true })

            } else {

                const already_embed = new EmbedBuilder()

                .setDescription(`There is already a sticky message in this channel, please unstick it with \`unstick\`.`)

                .setColor("Red")

    

                return await i.reply({ embeds: [already_embed], ephemeral: true })

            }

        })

    }

}