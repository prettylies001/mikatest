const { SlashCommandBuilder } = require('@discordjs/builders');

const { Client, Message, Intents } = require('discord.js');

const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

function hexy(rrggbb) {

	var bbggrr =

		rrggbb.substr(4, 2) + rrggbb.substr(2, 2) + rrggbb.substr(0, 2);

	return parseInt(bbggrr, 16);

}

module.exports = {

	data: new SlashCommandBuilder()

		.setName('weather')

		.setDescription('gets the weather')

		.addStringOption((option) =>

			option

				.setName('place')

				.setDescription('country/city/etc')

				.setRequired(true)

		),

		

	async execute(interaction) {

		try {

			interaction.deferReply();

			fetch(

				`https://goweather.herokuapp.com/weather/${interaction.options.getString(

					'place'

				)}`

			)

				.then((res) => res.json())

				.then(async (json) => {

					if (json) {

						if (json.temperature) {

							const { EmbedBuilder } = require('discord.js');

							const embedy = new EmbedBuilder()

								.setTitle(

									interaction.options.getString('place')

								)

								//  .setAuthor(interaction.member.displayName, interaction.author.avatarURL())

								.setDescription(json.description)

								.setColor(

									hexy(

										Math.floor(

											Math.random() * 16777215

										).toString(16)

									)

								)

								.setTimestamp()
.setImage("https://i0.wp.com/codemyui.com/wp-content/uploads/2015/07/pure-css-animated-weather-icons.gif")
								.addFields(

									{

										name: 'Temperature',

										value: `🌡️${json.temperature}`,

									},

									{ name: 'Wind', value: `💨${json.wind}` }

								);

							let hidden = true;

							if (

								interaction.options.getString('hidden') ===

									'no' ||

								interaction.options.getString('hidden') ===

									'no'.toLowerCase() ||

								interaction.options.getString('hidden') ===

									'no'.toUpperCase()

							) {

								hidden = false;

							} else {

								hidden = true;

							}

							await interaction.editReply({

								embeds: [embedy],

								ephemeral: hidden,

							});

						}

					}

				});

		
} catch (error) {

        console.error(error);

        return interaction.followUp({

          content:

            "An error has occurred while processing the information, please try again later.",

          ephermeral: true,

        });

      }
	
}
    }
	

	

	

	

	

	

	



