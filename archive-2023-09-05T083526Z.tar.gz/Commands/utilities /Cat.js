
const { ButtonStyle } = require('discord.js');
const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder } = require('discord.js');
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
const catAPIUrl = 'https://api.thecatapi.com/v1/images/search';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('cat')
    .setDescription('Shows a random cat picture'),

  async execute(interaction) {
    await interaction.deferReply();

    try {
      const catData = await fetch(catAPIUrl).then((response) => response.json());
      const catImageUrl = catData[0]?.url;

      if (!catImageUrl) {
        await interaction.followUp('Failed to fetch cat picture. 😿');
      } else {
        const embed = {
          title: 'Meow! 🐱',
          image: { url: catImageUrl },
          footer: { text: 'Click the button to see a different cat!' },
        };

        const row = new ActionRowBuilder()
          .addComponents(new ButtonBuilder().setCustomId('reload_cat').setLabel('Reload').setStyle(ButtonStyle.Primary));

        await interaction.followUp({ embeds: [embed], components: [row] });

        // Add a button interaction event listener
        const filter = (i) => i.customId === 'reload_cat' && i.user.id === interaction.user.id;
        const collector = interaction.channel.createMessageComponentCollector({ filter, time: 150000 });

        collector.on('collect', async (i) => {
          await i.deferUpdate();

          try {
            const newCatData = await fetch(catAPIUrl).then((response) => response.json());
            const newCatImageUrl = newCatData[0]?.url;

            if (!newCatImageUrl) {
              await i.followUp('Failed to fetch a different cat picture. 😿');
            } else {
              const newEmbed = {
                title: 'Meow! 🐱',
                image: { url: newCatImageUrl },
                footer: { text: 'Click the button to see a different cat!' },
              };

              await i.editReply({ embeds: [newEmbed], components: [row] });
            }
          } catch (error) {
            console.error('Error fetching a different cat picture:', error);
            await i.followUp('Failed to fetch a different cat picture. 😿');
          }
        });

        collector.on('end', (collected, reason) => {
          if (reason === 'time') {
            interaction.followUp('The cat selection timed out. 🕒');
          }
        });
      }
    } catch (error) {
      console.error('Error fetching cat picture:', error);
      await interaction.followUp('Failed to fetch cat picture. 😿');
    }
  },
};

