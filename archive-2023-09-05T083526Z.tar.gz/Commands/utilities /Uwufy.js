const { SlashCommandBuilder } = require('@discordjs/builders');

module.exports = {

    data: new SlashCommandBuilder()

        .setName('uwufier')

        .setDescription('Uwufy words in your message')

        .addStringOption(option => option.setName('message').setDescription('The message to be uwufied')),

    async execute(interaction) {

        const message = interaction.options.getString('message');

        if (message) {

            // Replace any instances of 'cat' with 'dog'

            const replacedText = message.replace(/love/g, 'wuvv')

                // Replace any instances of 'hippo' with 'elephant
              .replace(/super/g, 'supew ^-^')
              .replace(/pwobwem/g, 'problem')
            .replace(/hungry/g, 'hungwy')
            .replace(/bad/g, 'bad •screams•')
            .replace(/depressed/g, 'depwessed')
            .replace(/bruh/g, 'Bwuh')
            .replace(/bro/g, 'bwo')
              .replace(/myself/g, 'mysewf')
            .replace(/happened/g, 'Happenyed')
              .replace(/say/g, 'say *twerks*')
              .replace(/aww/g, 'aww >w<')
              .replace(/sorry/g, 'sowwy')
              .replace(/disappeared/g, 'disappeawed')
              .replace(/should/g, 'shouwd')
            .replace(/from/g, 'fwom')
            .replace(/friends/g, 'fwiends')
            .replace(/friend/g, 'fwiend')
            .replace(/the/g, 'da')
.replace(/something/g, 'Somethim')
                .replace(/you/g, 'yu');

            await interaction.reply(replacedText);

        } else {

            await interaction.reply('Please provide a message to be uwufied.');

        }

    },

};

