const { SlashCommandBuilder } = require('@discordjs/builders');

const { EmbedBuilder, ActionRowBuilder,ButtonStyle, ButtonBuilder } = require('discord.js');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('cookieclicker')

    .setDescription('Play the cookie clicker game!'),

  async execute(interaction) {

    // Initial cookie count

    let cookies = 0;

    // Create the button row

    const buttonRow = new ActionRowBuilder()

      .addComponents(

        new ButtonBuilder()

          .setCustomId('cookie')

          .setLabel('Tap')

          .setStyle(ButtonStyle.Primary),

      );

    // Create the embed to display the cookie count

    const embed = {

      title: 'Cookie Clicker',

      

      fields: [

        {

          name: 'Cookies 🍪',

          value: cookies,

          inline: true,

        },

      ],

    };

    // Send the initial message with the button and embed

    const initialMessage = await interaction.reply({

      content: 'Click the button to get cookies!',

      components: [buttonRow],

      embeds: [embed],

    });

    // Create a collector to listen for button clicks

    const filter = i => i.customId === 'cookie' && i.user.id === interaction.user.id;

    const collector = initialMessage.createMessageComponentCollector({ filter, time: 60000 });

    // When a button is clicked, increment the cookie count and update the embed

    collector.on('collect', async i => {

      cookies++;

      embed.fields[0].value = cookies;

      await i.update({ embeds: [embed] });

    });

    // When the collector ends (either because the time limit has been reached or the user has clicked the button 10 times),

    // update the initial message to remove the button and display the final score

    collector.on('end', async collected => {

      buttonRow.components[0].setDisabled(true).setLabel('Game over');
      embed.title = 'Cookies Collected ';
      const imacow = new EmbedBuilder() 
      .setImage("https://i.pinimg.com/originals/24/5b/e4/245be43dd4a8eee421a468db3b2ef86a.gif")
      await interaction.followUp({ components: [buttonRow], embeds: [embed,imacow] });

    });

  },

};

