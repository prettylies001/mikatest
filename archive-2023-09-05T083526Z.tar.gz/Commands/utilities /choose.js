const { SlashCommandBuilder, SlashCommandStringOption } = require('@discordjs/builders');

module.exports = {

    data: new SlashCommandBuilder()

        .setName('choose')

        .setDescription('Make me choose between infinite options')

        .addStringOption(option =>

            option.setName('options')

                .setDescription('Enter options for me to choose from just add some space')

                .setRequired(true)),

   async execute(interaction, message, Discord) {

    const target = interaction.options.getString("options")

     const args = target.trim().split(" ");

        interaction.reply({

            content: `I choose **${args[Math.floor(Math.random() * args.length)]}**`

        })

}

};