const { SlashCommandBuilder } = require('@discordjs/builders');

const axios = require('axios');

const { EmbedBuilder } = require('discord.js');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('wikipedia')

    .setDescription('Searches Wikipedia for a given query.')

    .addStringOption(option => option.setName('query').setDescription('The query to search for.').setRequired(true)),

  async execute(interaction) {

    const query = interaction.options.getString('query');

    try {

      const { data } = await axios.get(`https://en.wikipedia.org/w/api.php?action=query&format=json&prop=extracts&generator=search&exchars=1000&exintro=1&explaintext=1&gsrsearch=${encodeURIComponent(query)}&gsrlimit=1&gsrenablerewrites=1&redirects=1`);

      const page = data.query.pages[Object.keys(data.query.pages)[0]];

      const extract = page.extract.length > 2048 ? `${page.extract.substring(0, 497)}...` : page.extract;

      const embed = new EmbedBuilder()

        .setColor('Random')

        .setTitle(page.title)

        .setURL(`https://en.wikipedia.org/wiki/${encodeURIComponent(page.title.replace(/ /g, '_'))}`)

        .setDescription(extract)


        

      
      await interaction.reply({ embeds: [embed] });

    } catch (error) {

      console.error(error);

      await interaction.reply('An error occurred while searching Wikipedia.');

    }

  },

};

