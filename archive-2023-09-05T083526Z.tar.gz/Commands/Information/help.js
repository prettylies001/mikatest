const { ChatInputCommandInteraction, SlashCommandBuilder, EmbedBuilder, ActionRowBuilder,  StringSelectMenuBuilder
} = require("discord.js")

module.exports = {
  data: new SlashCommandBuilder()
  .setName("help")
  .setDescription("Sends the help menu"),
  /**
  *
  * @param {ChatInputCommandInteraction} interactin
*/
  execute(interactin) {
    const row = new ActionRowBuilder()
    .addComponents(
      new StringSelectMenuBuilder()


      .setCustomId("help")
      .setPlaceholder("help menu")
      .addOptions([
        {
          label: "Moderation Commands",
          description: "Click here to select Moderation Commands",
          value: "mod",
        },
        {
          label: "Fun Commands",
          description: "Click here to select Fun Commands",
          value: "fun",
        },
        {
          label: "Information Commands",
          description: "Click here to select Information Commands",
          value: "info",
        },
        ])
      )
    const embed = new EmbedBuilder()
    .setTitle("Help Menu")
    .setDescription("Select from the menu below me to view my commands.")  .setThumbnail("https://cdn3.emoji.gg/emojis/1452-sparkles.gif") .setImage("https://wallpapercave.com/uwp/uwp681552.gif")
    interactin.reply({ embeds: [embed], components: [row]})
    const embed1 = new EmbedBuilder()
    .setTitle("Fun Commands")
    .setDescription("/meme, /flip, /say, /howgay, /achieve, /Games, /hug, /kiss, /lick, /slap")
    const embed2 = new EmbedBuilder()
    .setTitle("Information Commands")
    .setDescription("/help, /invite, /support /userinfo, /botinfo, /serverinfo, /ping, /uptime, /google, /annoucement, /github")
    const embed3 = new EmbedBuilder()
    .setTitle("Moderation Commands")
    .setDescription("/kick, /ban, /mute, /unmute, /warn, /checkwarns, /clearwarns")

    
    let filter = i => i.user.id === interactin.user.id
    let collector = interactin.channel.createMessageComponentCollector({filter : filter})
    collector.on("collect", async (i) => {
      if(i.isStringSelectMenu()) {
        if(i.customId === "help") {
          await i.deferUpdate().catch(e => {})
          let [ directory ] = i.values
          const value = i.values[0]
          if(value === "fun") {
            interactin.followUp({ embeds: [embed1], ephemeral: true})
          }
          if(value === "info"){
            interactin.followUp({ embeds: [embed2], ephemeral: true})
          }
          if(value === "mod") {
            interactin.followUp({ embeds: [embed3], ephemeral: true})
          }
        }
      }
    })
    
  }
}