const { ChatInputCommandInteraction, SlashCommandBuilder, EmbedBuilder } = require("discord.js")

module.exports = {
  data: new SlashCommandBuilder()
  .setName("memberscount")
  .setDescription("replies with the current server members count"),
  /**
  *
  * @param {ChatInputCommandInteraction} interaction
  */
  execute(interaction) {
    if(!interaction.guild) {
      const memberErr = new EmbedBuilder()
      .setTitle("Members Count")
      .setDescription("You can not use this command in DMS (Direct Messages)")
      return interaction.reply({ embeds: [memberErr]})
    }
    const embed = new EmbedBuilder()
    .setTitle("Members Count")
    .setDescription(`**Total Members**\n${interaction.guild.memberCount}\n**Humans**\n${interaction.guild.members.cache.filter(member => !member.user.bot).size}\n**Bots**\n${interaction.guild.members.cache.filter(member => member.user.bot).size}`)
    interaction.reply({ embeds: [embed]})
  }
}