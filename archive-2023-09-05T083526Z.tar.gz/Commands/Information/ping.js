const { ChatInputCommandInteraction, SlashCommandBuilder, EmbedBuilder} = require("discord.js")

module.exports = {
   
  data: new SlashCommandBuilder()
  .setName("ping")
  .setDescription("Replies with the api ping latency"),
   
  /**
  *
  * @param {ChatInputCommandInteraction} interactin
*/
async execute ( interaction, client) {
     


     
        
 const embed = new EmbedBuilder()
    .setTitle("Ping")
    .setDescription(` Api Ping Latency: **${Math.round(client.ws.ping)}** ms`)
 console.log(`${interaction.user.tag}`)
    interaction.reply({ embeds: [embed]})
  }
}
    
