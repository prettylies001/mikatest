const { Client, ChatInputCommandInteraction, SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js")

module.exports = {
  data: new SlashCommandBuilder()
  .setName("invite")
  .setDescription("Sends the bot invite"),
  /**
  *
  * @param {ChatInputCommandInteraction} interactin
*/
  execute(interaction, client) {
      
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
        .setLabel("Invite Me")
    .setStyle(ButtonStyle.Link)   .setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot`)  
      )
    const embed = new EmbedBuilder()
    .setTitle("Invite")
    .setImage('https://giffiles.alphacoders.com/194/194658.gif')
    
    .setDescription(`Click [here](https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot) to invite me with administrator permission.\n Click [here](https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=0&scope=bot) to invite me with non admin permission, or click the button below me to invite me`)
     interaction.reply({ embeds: [embed], components: [row] });
  }
}