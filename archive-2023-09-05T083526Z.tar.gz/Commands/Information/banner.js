const { Client, ActionRowBuilder, ButtonStyle,ButtonBuilder,SlashCommandBuilder, EmbedBuilder, Embed } = require('discord.js')

const axios = require('axios');

module.exports = {

    data: new SlashCommandBuilder()

    .setName("banner")

    .setDescription("Get a user banner or color")

    .addUserOption(

        option =>

        option.setName('user')

        .setDescription('the user you wanna stalk')

        .setRequired(true)

          )

.addBooleanOption(

        option =>

        option.setName('color')

        .setDescription('wanna see color ones?')

        .setRequired(true)

          ),

    /**

     * 

     * @param {Client} client 

     * @param {CommandInteraction} interaction 

     */

    async execute(interaction, client)  {

        const user = await interaction.options.getUser('user');

        const color = await interaction.options.getBoolean('color');
banner = user.bannerURL({

                        dynamic: true,

                        size: 512,

                    })
                        
        return interaction.client.users.fetch(user.id, { force: true }).then(async(result) => {

            const embedThing = new EmbedBuilder()

                .setAuthor({ name: result.tag, iconURL: result.displayAvatarURL({ dynamic: true }) })

                .setColor("36393E")

            if(!color) {

                if (!result.banner) {

                    return interaction.reply({ content: `**${result.tag}** has no banner!` })

                }
const embedThingy = new EmbedBuilder()

                .setAuthor({ name: result.tag, iconURL: result.displayAvatarURL({ dynamic: true }) })
.setImage(banner)
                .setColor("36393E")
                const button = new ActionRowBuilder()

                    .addComponents(new ButtonBuilder()

                        .setStyle(ButtonStyle.Link)

                        .setLabel("Open in Browser")

                        .setURL(result.bannerURL({ dynamic: true, size: 512 })));

    

                return interaction.reply({ embeds: [embedThingy], components: [button] });

            }

            if(!result.hexAccentColor) {

                console.log(result.tag)

                return interaction.reply({ content: `**${result.tag}** has no banner color!` })

            }

            if(result.hexAccentColor === null) {

                return interaction.reply({ content: `**${result.tag}**'s banner color is default, and I am unable to fetch it.` })

            }

            const headers = { 'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 11_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.106 Safari/537.36' };

            const data = await axios.get(`http://www.thecolorapi.com/id?hex=${result.hexAccentColor?.replace(/#/g, '')}`, { headers }).then(res => res.data);

            embedThing.setColor(data.hex.clean);

            embedThing.setDescription([

                `***ID:*** \`${result.id}\``,

                `***Hex:*** \`${data.hex.value}\``

            ].join("\n"));

            embedThing.setImage(`https://serux.pro/rendercolour?hex=${data.hex.clean}&height=200&width=512`)

            return interaction.reply({ embeds: [embedThing] });

        })

    }

}