const { ChatInputCommandInteraction, SlashCommandBuilder, ActionRowBuilder, ButtonStyle, ButtonBuilder, EmbedBuilder } = require("discord.js")

module.exports = {
  data: new SlashCommandBuilder()
  .setName("support")
  .setDescription("Sends the bot support server"),
  /**
  *
  * @param {ChatInputInteraction} interactin
*/
  execute(interactin) {
    const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
      .setLabel("Support Server")
      .setStyle(ButtonStyle.Link)   .setURL("https://discord.gg/a6MdgxJGXW")
    )
    const embed = new EmbedBuilder()
    .setTitle("Support")
    .setDescription("Click [here](https://discord.gg/a6MdgxJGXW) to or the button below me join the support server")
    interactin.reply({ embeds: [embed], components: [row]})
  }
}