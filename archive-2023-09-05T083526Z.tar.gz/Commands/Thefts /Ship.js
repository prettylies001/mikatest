const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('ship')

    .setDescription('Calculate the love compatibility between two users')

    .addUserOption(option => option.setName('user1').setDescription('The first user').setRequired(false))

    .addUserOption(option => option.setName('user2').setDescription('The second user').setRequired(false)),

  async execute(interaction) {
  const { user, guild } = interaction;
  const user1 = interaction.options.getUser('user1') || user;
  const user2 = interaction.options.getUser('user2') || guild.members.cache.filter(m => !m.user.bot && m.id !== user.id).random().user;
  
const love = Math.floor(Math.random() * 100);
  const meterEmpty = Math.floor(love / 10);
  const meterFilled = '❤️'.repeat(meterEmpty) + '⬛'.repeat(10 - meterEmpty);

  let message = '';
  if (love <= 10) {
    message = `💔 Matchmaking 💔 \n 🔻 ${user1.username} \n 🔺 ${user2.username} \n have a ${love}% compatibility... maybe it's time to move on.`;
  } else if (love <= 50) {
    message = ` ♥️ Matchmaking ♥️ \n 🔻${user1.username} \n🔺${user2.username} \n have a ${love}% compatibility. It could be better, but there's hope!`;
  } else if (love <= 90) {
    message = `❤️ Matchmaking ❤️ \n 🔻 ${user1.username} \n 🔺 ${user2.username} \n have a ${love}% compatibility. That's pretty good!`;
  } else {
    message = `💕 Matchmaking 💕 \n 🔻${user1.username}  \n🔺${user2.username} \n have a ${love}% compatibility! That's amazing, you're meant to be together!`;
  }
const shipName = user1.username.slice(0, Math.floor(user1.username.length / 2)) + user2.username.slice(Math.floor(user2.username.length / 2));

  
  const embed = new EmbedBuilder()
    .setColor('#2f3136')
    .setAuthor({
      name: `${shipName} ❤️`,
      iconURL: user1.displayAvatarURL({ dynamic: true }),
    })
  .setImage(`https://37.media.tumblr.com/81a60eeeb78cdd1feca14375836db2bf/tumblr_n7e8arpJoG1tqk5eio1_500.gif`)

    .setDescription(`${meterFilled} ${love}%`)
  

  await interaction.reply({ embeds: [embed], content: message });
}
}