const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder,ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('envelope')
        .setDescription('Send an interactive message (envelope) to a selected user')
        .addUserOption(option => option.setName('user').setDescription('Select a user').setRequired(true))
        .addStringOption(option => option.setName('message').setDescription('Write a message').setRequired(true))
        .addStringOption(option => option.setName('image').setDescription('Attach an image').setRequired(false)),
    async execute(interaction) {
        const user = interaction.options.getUser('user');
        const message = interaction.options.getString('message');
        const image = interaction.options.getString('image');

        // Create the envelope message embed
        const envelopeEmbed = new EmbedBuilder()
            .setTitle('You have received a new message!')
            .setDescription(`**From:** ${interaction.user}\n\nClick the button below to open the message.`)
        .setImage('https://media.tenor.com/LykRrkxSE9kAAAAC/hi-hello.gif')
            
            .setTimestamp();

        // Add the optional image attachment, if provided
        if (image) {
            envelopeEmbed.setImage(image);
        }

        // Create the "Open" button for the selected user
        const openButton = new ButtonBuilder()
            .setCustomId('open_envelope')
            .setLabel('Open')
            .setStyle(ButtonStyle.Primary);

        // Create the action row with the "Open" button
        const actionRow = new ActionRowBuilder().addComponents(openButton);

        // Send the envelope message embed with the "Open" button to the selected user
        try {
            const dmChannel = await user.createDM();
            const envelopeMessage = await dmChannel.send({ embeds: [envelopeEmbed], components: [actionRow] });

            // Only the selected user can see and click the "Open" button
            const filter = i => i.customId === 'open_envelope' && i.user.id === user.id;
            const collector = envelopeMessage.createMessageComponentCollector({ filter, time: 0 });

            collector.on('collect', async i => {
                // Update the envelope message embed to reveal the message and the optional image attachment
                envelopeEmbed.setDescription(`**From:** ${interaction.user}\n\n**Message:** ${message}`);
                envelopeEmbed.setFooter({text:'This message was sent directly to you.'});

                // Remove the "Open" button from the action row
                

                await i.update({ embeds: [envelopeEmbed], components: [] });
                collector.stop();
            });

            collector.on('end', collected => {
                if (collected.size === 0) {
                    envelopeMessage.edit({ components: [] });
                }
            });

            await interaction.reply({content:`The message has been sent to ${user}!`,ephemeral: true});
        } catch (error) {
            console.error(`Failed to send a DM to ${user}:`, error);
            await interaction.reply(`Failed to send a message to ${user}!`);
        }
    },
};
