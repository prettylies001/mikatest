const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder } = require('discord.js');
const fs = require('fs');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('Displays information about a user')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user to get information about')
        .setRequired(false)
    )
    .addStringOption(option =>
      option.setName('pronouns')
        .setDescription('The pronouns you want to set')
        .setRequired(false)
    )
    .addBooleanOption(option =>
      option.setName('public')
        .setDescription('Whether to make the response public or not')
        .setRequired(false)
        
    ),
  async execute(interaction,client) {
    const user = interaction.options.getUser('user') || interaction.user;
    const member = interaction.guild.members.cache.get(user.id);

    let pronouns = 'not set';
    if (interaction.options.getString('pronouns')) {
      if (interaction.user.id === user.id) {
        pronouns = interaction.options.getString('pronouns');
        const pronounsData = JSON.parse(fs.readFileSync('pronouns.json'));
        pronounsData[user.id] = pronouns;
        fs.writeFileSync('pronouns.json', JSON.stringify(pronounsData));
      } else {
        await interaction.reply({
          content: "You can't set pronouns for other users.",
          ephemeral: true
        });
        return;
      }
    } else {
      const pronounsData = JSON.parse(fs.readFileSync('pronouns.json'));
      pronouns = pronounsData[user.id] || 'not set';
    }

    const userCreatedAt = user.createdAt.toUTCString();
    const memberJoinedAt = member.joinedAt.toUTCString();

    const isBot = user.bot ? 'Yes' : 'No';
    let banner = await (await client.users.fetch(user.id, { force: true })).bannerURL({ dynamic: true, size: 4096 });



      
    const image = banner ? banner : user.displayAvatarURL({ dynamic: true });
    const color = banner ? null : member.displayColor;

    const embed = new EmbedBuilder()
    .setAuthor({name:`*${user.username}'s Info*`,iconURL: user.displayAvatarURL({ dynamic: true }),

})
      .setColor(color || '#0099ff')
      
      .setImage(image)
      .addFields({ name: 'Username', value: user.tag, inline: true })
      .addFields({ name: 'ID', value: user.id, inline: true })
      .addFields({ name: 'Joined Discord on', value: userCreatedAt, inline: true })
      .addFields({ name: `Joined ${interaction.guild.name} server on`, value: memberJoinedAt, inline: true })
    

  .addFields({name:'Roles', value:member.roles.cache.filter(role => role.name !== '@everyone').map(role => role.toString()).join(', ') || 'None', inline:true})
       

                   
      .addFields({ name: 'Pronouns', value: pronouns, inline: true })
      .addFields({ name: 'Bot', value: isBot, inline: true })
      .setTimestamp();

    const isEphemeral = interaction.options.getBoolean('public') === false;
    await interaction.reply({ embeds: [embed], ephemeral: isEphemeral });
  },
};
