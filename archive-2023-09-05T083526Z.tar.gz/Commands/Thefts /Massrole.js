const { SlashCommandBuilder } = require('@discordjs/builders');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('massrole')
        .setDescription('Give a role to all members in the server.')
        .addRoleOption(option =>
            option.setName('role')
                .setDescription('The role to give to all members in the server.')
                .setRequired(true)),
    async execute(interaction) {
        const role = interaction.options.getRole('role');

        // Fetch all members in the server
        const members = await interaction.guild.members.fetch();

        // Give the role to each member
        members.forEach(member => {
            member.roles.add(role);
        });

        // Send a response
        await interaction.reply(`Gave the "${role.name}" role to all members in the server.`);
    },
};
