const { SlashCommandBuilder } = require('@discordjs/builders');
const { version } = require('discord.js');
const moment = require('moment');
const os = require('os');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('botinfo')
        .setDescription('Displays information about the bot.'),
    async execute(interaction) {
        const { client } = interaction;

        const uptime = moment.duration(client.uptime).humanize();
        const guildCount = client.guilds.cache.size;
        const channelCount = client.channels.cache.size;
        const userCount = client.users.cache.size;
        const nodeVersion = process.version;
        const cpuInfo = os.cpus()[0].model;
        const ping = Math.round(client.ws.ping);
        
        const embed = {
            title: `${client.user.username} Info`,
           description: 'First Kashmiri bot ever!', 
            thumbnail: {
                url: client.user.avatarURL(),
            },
            fields: [
                {
                    name: ' Discord.js Version',
                    value: `v${version}`,
                },
                {
                    name: 'Uptime',
                    value: uptime,
                },
                {
                    name: 'Guilds',
                    value: guildCount,
                    inline: true,
                },
                {
                    name: 'Channels',
                    value: channelCount,
                    inline: true,
                },
                {
                    name: 'Users',
                    value: userCount,
                    inline: true,
                },
                {
                    name: 'Node.js Version',
                    value: nodeVersion,
                },
                {
                    name: 'CPU',
                    value: cpuInfo,
                },
                {
                    name: 'Ping',
                    value: `${ping}ms`,
                },
                {

                    name: 'commands',

                    value: `${interaction.client.commands.size}`,

                    inline: true,

                },
                {
                    name: 'Owner',
                    value: 'You are',
                    inline: true,
                },
            ],
            timestamp: new Date(),
        };

        await interaction.reply({ embeds: [embed] });
    },
};
