const { ChatInputCommandInteraction, SlashCommandBuilder, PermissionsBitField, PermissionFlagsBits, EmbedBuilder } = require("discord.js")

module.exports = {
    data: new SlashCommandBuilder()
    .setName("ban")
    .setDescription("Bans the mentioned user")
    .setDefaultMemberPermissions(PermissionsBitField.KickMembers)
    .addUserOption((option) =>
    option.setName("user")
    .setDescription("The user to ban")
    .setRequired(true))
    .addStringOption((option) => 
    option.setName("reason")
    .setDescription("The reason for the ban [OPTIONAL]")
    .setRequired(false)),
    /**
     * 
     * @param {ChatInputCommandInteraction} interaction
     */
   async execute(interaction) {
        const target = interaction.options.getMember("user")
        const author = interaction.user.id
        const reason = interaction.options.getString("reason") || "No reason provided";
        if(!target) {
            const kickErr5 = new EmbedBuilder()
            .setTitle("Ban")
            .setDescription("Failed to ban, because this user does not exist, or this user is not in this server")
            return interaction.reply({ embeds: [kickErr5]})
        }
         if(!interaction.member.permissions.has(PermissionFlagsBits.BanMembers)) {
            const kickErr1 = new EmbedBuilder()
            .setTitle("Ban")
            .setDescription("You are missimg the `Ban Members` permission")
            return interaction.reply({ embeds: [kickErr1]})
         }
         if(!interaction.guild.members.me.permissions.has(PermissionFlagsBits.BanMembers)) {
            const kickErr2 = new EmbedBuilder()
            .setTitle("Ban")
            .setDescription("I'm missing the `Ban Members` permission")
            return interaction.reply({ embeds: [kickErr2]})
         }
         if(target.roles.highest.position >= interaction.member.roles.highest.position) {
            const kickErr3 = new EmbedBuilder()
            .setTitle("Ban")
            .setDescription("You can not ban this member, because this member has a role that is equal to your role, or higher than your role.")
            return interaction.reply({ embeds: [kickErr3]})
         }
         if(target.roles.highest.position >= interaction.guild.members.me.roles.highest.position) {
            const kickErr4 = new EmbedBuilder()
            .setTitle("Ban")
            .setDescription("I can not ban someone with a role that is equal to my role, or higher than my role")
            return interaction.reply({ embeds: [kickErr4]})
         }
        if(target.id === interaction.user.id) {
            const kickErr = new EmbedBuilder()
            .setTitle("Ban")
            .setDescription("Failed to ban, You can not ban yourself")
           return interaction.reply({ embeds: [kickErr]})
        }
       target.ban({ reason: `${reason} Banned by ${interaction.user.tag}`}).then(() => {
        const embed = new EmbedBuilder()
        .setTitle("Ban")
        .setDescription(`Successfully banned ${target}\n**By**\n<@${interaction.user.id}>\n**Reason**\n${reason}`)
        interaction.reply({ embeds: [embed]}) 
           
  
        
 
       }).catch((err) => {
        const kickErr = new EmbedBuilder()
        .setTitle("Ban")
        .setDescription(`An error occurred, ${err}`)
        return interaction.reply({ embeds: [kickErr]})
       })
}
}