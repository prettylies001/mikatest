const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mass-ban')
    .setDescription('Ban multiple users at once')
    .addStringOption(option =>
      option.setName('users')
        .setDescription('List of user IDs or mentions to ban')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for the ban')),

  async execute(interaction) {
    const users = interaction.options.getString('users');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    const bannedUsers = [];

    
    const userIDs = users.split(/\s+/).map(userID => userID.replace(/[^\d]/g, ''));

    for (const userID of userIDs) {
      try {
        const bannedUser = await interaction.guild.members.ban(userID, { reason });
        if (bannedUser) {
          bannedUsers.push(bannedUser);
        }
      } catch (error) {
        console.error(`Failed to ban user with ID ${userID}:`, error);
      }
    }

    if (bannedUsers.length === 0) {
      return interaction.reply('No users were banned.');
    }

    const bannedUserTags = bannedUsers.map(user => user.username).join(', ');

    await interaction.reply(`Successfully banned the following users: ${bannedUserTags}`);
  },
};
