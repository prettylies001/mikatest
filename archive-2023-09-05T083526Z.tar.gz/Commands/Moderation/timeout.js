const { ChatInputCommandInteraction, SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require("discord.js")
const ms = require("ms")

module.exports = {
  data: new SlashCommandBuilder()
  .setName("timeout")
  .setDescription("timeout the mentioned user and removes their ability to chat")
 .addUserOption((option) => 
                option.setName("user")
                .setDescription("the user to Mute")
                .setRequired(true))
  .addStringOption((option) => 
                  option.setName("duration")
                  .setDescription("the timeout duration")
                  .setRequired(true))
  .addStringOption((option) => 
                  option.setName("reason")
                  .setDescription("reason for the Timeout [OPTIONAL]")
    .setMaxLength(512)
                  .setRequired(false)),
  /**
  *
  * @param {ChatInputCommandInteraction} interaction
  */
  execute(interaction) {
    const target = interaction.options.getMember("user")
    const duration = interaction.options.getString("duration")
    const reason = interaction.options.getString("reason") || "No reason provided";
    if(!interaction.guild) {
      const timeoutErr6 = new EmbedBuilder()
      .setTitle("Mute")
      .setDescription("You can not use this command in DMS (Direct Messages)")
      return interaction.reply({ embeds: [timeoutErr6]})
    }
                  if(!target) {
                    const timeoutErr = new EmbedBuilder()
                    .setTitle("Mute")
                    .setDescription("Failed to Give Timeout, because either this user does not exists, or the user is not in this server")
                    return interaction.reply({ embeds: [timeoutErr]})
                  }
    if(!ms(duration) || ms(duration) > ms("28d")) {
      const timeoutErr1 = new EmbedBuilder()
      .setTitle("Timeout")
      .setDescription("Failed to Mute, because either provided duration is invalid, or timeout duration provided is over the discord timeout maximum length `28 days`")
      return interaction.reply({ embeds: [timeoutErr1]})
    }
    if(!interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      const timeoutErr2 = new EmbedBuilder()
      .setTitle("Timeout")
      .setDescription("You are missing the `Moderate Members` permission")
      return interaction.reply({ embeds: [timeoutErr2]})
    }
    if(!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      const timeoutErr3 = new EmbedBuilder()
      .setTitle("Timeout")
      .setDescription("I'm missing the `Moderate Members` permission")
      return interaction.reply({ embeds: [timeoutErr3]})
    }
    if(target.roles.highest.position >= interaction.member.roles.highest.position) {
      const timeoutErr4 = new EmbedBuilder()
      .setTitle("Timeout")
      .setDescription("You can not timeout a member that has a role that is equal to your role, or higher than your role")
      return interaction.reply({ embeds: [timeoutErr4]})
    };
    
    if(target.roles.highest.position >= interaction.guild.members.me.roles.highest.position) {
      const timeoutErr5 = new EmbedBuilder()
      .setTitle("Timeout")
      .setDescription("I can not timeout a member with a role that is equal to my role, or higher than my role")
      return interaction.reply({ embeds: [timeoutErr5]})
    }
    target.timeout(ms(duration), reason).catch((err) => {
      const embedErr = new EmbedBuilder()
      .setTitle("Timeout")
      .setDescription(`An error occurred, ${err}`)
      return interaction.reply({ embeds: [embedErr]})
    })
        const embed = new EmbedBuilder()
        .setTitle("Timeout")
        .setDescription(`Successfully timed out ${target}\n**By**\n<@${interaction.user.id}>\n**Duration**\n${duration}\n**Reason**\n${reason}`)
        interaction.reply({ embeds: [embed]})
    
      }
}