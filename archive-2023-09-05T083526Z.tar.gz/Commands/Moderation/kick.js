const { ChatInputCommandInteraction, SlashCommandBuilder, PermissionsBitField, PermissionFlagsBits, EmbedBuilder } = require("discord.js")

module.exports = {
    data: new SlashCommandBuilder()
    .setName("kick")
    .setDescription("Kicks the mentioned user")
    .setDefaultMemberPermissions(PermissionsBitField.KickMembers)
    .addUserOption((option) =>
    option.setName("user")
    .setDescription("The user to kick")
    .setRequired(true))
    .addStringOption((option) => 
    option.setName("reason")
    .setDescription("The reason for the kick [OPTIONAL]")
    .setRequired(false)),
    /**
     * 
     * @param {ChatInputCommandInteraction} interaction
     */
    execute(interaction) {
        const target = interaction.options.getMember("user")
        const author = interaction.user.id
        const reason = interaction.options.getString("reason") || "No reason provided";
      if(!interaction.guild) {
        const kickErr6 = new EmbedBuilder()
        .setTitle("Kick")
        .setDescription("You can not use this command in DMS (Direct Messages)")
        return interaction.reply({ embeds: [kickErr6]})
      }
        if(!target) {
         const kickErr5 = new EmbedBuilder()
         .setTitle("Kick")
         .setDescription("Failed to kick, because this user does not exist, or this user is not in this server")
         return interaction.reply({ embeds: [kickErr5]})
        }
         if(!interaction.member.permissions.has(PermissionFlagsBits.KickMembers)) {
            const kickErr1 = new EmbedBuilder()
            .setTitle("Kick")
            .setDescription("You are missing the `Kick Members` permission")
            return interaction.reply({ embeds: [kickErr1]})
         }
         if(!interaction.guild.members.me.permissions.has(PermissionFlagsBits.KickMembers)) {
            const kickErr2 = new EmbedBuilder()
            .setTitle("Kick")
            .setDescription("I'm missing the `Kick Members` permission")
            return interaction.reply({ embeds: [kickErr2]})
         }
         if(target.roles.highest.position >= interaction.member.roles.highest.position) {
            const kickErr3 = new EmbedBuilder()
            .setTitle("Kick")
            .setDescription("You can not kick this member, because this member has a role that is equal to your role, or higher than your role.")
            return interaction.reply({ embeds: [kickErr3]})
         }
         if(target.roles.highest.position >= interaction.guild.members.me.roles.highest.position) {
            const kickErr4 = new EmbedBuilder()
            .setTitle("Kick")
            .setDescription("I can not kick someone with a role that is equal to my role, or higher than my role")
            return interaction.reply({ embeds: [kickErr4]})
         }
        if(target.id === interaction.user.id) {
            const kickErr = new EmbedBuilder()
            .setTitle("Kick")
            .setDescription("Failed to kick, You can not kick yourself")
           return interaction.reply({ embeds: [kickErr]})
        }
       target.kick({ reason: `${reason} Kicked by ${interaction.user.tag}`}).then(() => {
        const embed = new EmbedBuilder()
        .setTitle("Kick")
        .setDescription(`Successfully kicked ${target}\n**By**\n<@${interaction.user.id}>\n**Reason**\n${reason}`)
        interaction.reply({ embeds: [embed]})
       }).catch((err) => {
        const kickErr = new EmbedBuilder()
        .setTitle("Kick")
        .setDescription(`An error occurred, ${err}`)
        return interaction.reply({ embeds: [kickErr]})
       })
}
}