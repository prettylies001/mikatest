const { SlashCommandBuilder } = require(`@discordjs/builders`);
const { PermissionsBitField, EmbedBuilder } = require(`discord.js`);

module.exports = {
  data: new SlashCommandBuilder()
  .setName("say")
  .setDescription("Sends a message to the selected channel")


.addStringOption((option) =>
  option
      .setName("yourmessage")
      .setDescription("embed description")
      .setRequired(true)
)
    .addAttachmentOption((options) =>

      options

        .setName("attachment")

        .setDescription("Attach a edivence")

        .setRequired(false)

    )
      .addChannelOption((option) =>

  option

      .setName("channel")

      .setDescription("channel you want to push this message to")

      .setRequired(false)

),

  async execute ( interaction ) {

        const {client, guild} = interaction;
      const userID = interaction.user.id
        const channelsend = interaction.options.getChannel("channel") || interaction.channel;
 const attach = interaction.options.getAttachment("attachment") || ""
     const  message= interaction.options.getString("yourmessage")
        
     const userId = '1059116301831909426'; // Replace this with your user ID

if (
  interaction.user.id !== userId &&
  !interaction.member.permissions.has(PermissionsBitField.FLAGS.ManageMessages)
) {
  return await interaction.reply({ content: "😔 You can't use the say command bro" });
}

// The rest of your code to handle the 'say' command here...


     


      await interaction.reply({
      embeds: [new EmbedBuilder()
             .setColor('#2f3136')
             .setDescription(`Succesfully sent **message** in ${channelsend}`)], ephemeral: true });
          if (attach) {

            
            await channelsend.send({ content: message, files: [attach] });

        } else {

            await channelsend.send(message);

        }
      
  }
}
