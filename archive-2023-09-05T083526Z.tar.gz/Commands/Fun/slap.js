const { ChatInputCommandInteraction, SlashCommandBuilder, EmbedBuilder } = require("discord.js")
const love = require("discord_love")

module.exports = {
  data: new SlashCommandBuilder()
  .setName("slap")
  .setDescription("slaps the mentioned user")
    .addUserOption((option) => 
                  option.setName("user")
                  .setDescription("slaps the mentioned user")
                  .setRequired(true)),
  /**
  *
  * @param {ChatInputCommandInteraction} interaction
  */
  execute(interaction) {
    const user = interaction.options.getMember("user")
    const embed = new EmbedBuilder()
    .setTitle("Slap")
    .setDescription(`<@${interaction.user.id}> slapped ${user}`)
    .setImage(love.slap())
    interaction.reply({ embeds: [embed]})
  }
}