const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

module.exports = {

    data: new SlashCommandBuilder()

        .setName('waifu')

        .setDescription('Get your waifu'),

    async execute(interaction, client) {

        let url = 'https://api.waifu.pics/sfw/waifu';

        let respuesta = await fetch(url).then(response => response.json());

        let link = respuesta.url;

         const embed1 = new EmbedBuilder()
  .setAuthor({

        name: (`hey ${interaction.user.username} Your Waifu`),

        iconURL: interaction.user.displayAvatarURL({ dynamic: true }),

      })


         

         .setImage(link)

         

         await interaction.reply({embeds: [embed1]});

    } 

}