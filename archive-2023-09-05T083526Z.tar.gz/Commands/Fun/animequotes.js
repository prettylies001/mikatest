const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require("discord.js");

const wait = require('node:timers/promises').setTimeout;

module.exports = {

  data: new SlashCommandBuilder()

    .setName("animequotes")

    .setDescription("Anime Quotes for you."),

async execute(interaction) {

  const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

const res = await fetch('https://animechan.xyz/api/random');

    const anime1 = (await res.clone());

    const animec1 = (await res.clone());

    const quote = (await res.json()).quote;

    const anime = (await anime1.json()).anime;

    const animec = (await animec1.json()).character;

    const embed = new EmbedBuilder()
.setAuthor({ name: 'Anime Quotes', iconURL: "https://media.tenor.com/vkaMuT1kJugAAAAd/ero-manga-sensei-izumi-sagiri.gif"})


    
    .setColor('#2f3136')
    
    .setDescription(`${quote}`)

      .addFields(

		{ name: 'Character', value: `${animec}` },

		{ name: 'Anime', value: `${anime}`, inline: true },

	)

    

    await interaction.deferReply();

		await wait(50);

    

  interaction.editReply({ embeds: [embed]})

  }

}