const { SlashCommandBuilder } = require("discord.js");

const { EmbedBuilder } = require('discord.js')

module.exports = {

  data: new SlashCommandBuilder()

    .setName("hug")

    .setDescription("hug someone.")

    .addUserOption((option) =>

      option.setName("user").setDescription("who to hug?").setRequired(true)

    ),

  async execute(interaction,client) {

    const user = interaction.options.getUser('user').username
const hugger = interaction.user.username;
    let recipient = interaction.options.getUser('user');
      if (recipient === interaction.user) return interaction.reply('Whilst patting yourself is technically allowed, you\'re not allowed to do it :)');
    const hugmsg = [

      `${hugger} hugs ${user} and ${user} hugs them back.`,

      `${hugger} hugs ${user}.`,

      `${hugger} hugs ${user}, and ${user} tells ${hugger} to take a shower`,

      `${hugger} hugs ${user} and they become best friends!`,

      `${hugger} asks ${user} for hug, and ${user} hugs them`,

      `${user} hugs ${hugger} before ${hugger} hugged them. ❤️`,

    ]

    const huggif = [

      "https://media.tenor.com/J7eGDvGeP9IAAAAC/enage-kiss-anime-hug.gif",

      "https://media.tenor.com/kCZjTqCKiggAAAAC/hug.gif",

      "https://media.tenor.com/8o4fWGwBY1EAAAAd/aharensan-aharen.gif",

      "https://media.tenor.com/8BqG6yTLCLEAAAAC/anime.gif",

      "https://media.tenor.com/PEEVUgby2p0AAAAd/anime-anime-hug.gif",

      "https://media.tenor.com/rTKIBe2qtxsAAAAC/anime-couples.gif",

      "https://media.tenor.com/FJRptuv4oX8AAAAC/hug-k-on.gif"

    ]

    const hgm2 = hugmsg[Math.floor(Math.random() * hugmsg.length)];

    const hgifoutput = huggif[Math.floor(Math.random() * huggif.length)];

    const exampleEmbed = new EmbedBuilder()
    .setAuthor({

        name: hgm2,

        iconURL: interaction.user.displayAvatarURL({ dynamic: true }),

      })

      

     

      .setImage(hgifoutput)



 const message = await   interaction.reply({ embeds: [exampleEmbed], fetchReply: true
                                            });
 

   message.react('<a:Huggies:1058357274931896381>');                  

  },

};