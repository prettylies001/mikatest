const { SlashCommandBuilder } = require('@discordjs/builders');

const { EmbedBuilder } = require('discord.js');



module.exports = {

	data: new SlashCommandBuilder()

        .setName('dadjokes')

        .setDescription('Random dadjokes'),

    async execute(interaction, client, config) {

        try {
const fetch = async data => (await import('node-fetch')).default(data);

            // This 3 line good for api

            let response = await fetch(`https://icanhazdadjoke.com/slack`);

            let data = await response.text();

            const img = JSON.parse(data)

            const embed = new EmbedBuilder()

                .setFooter({text: `Dad(dy) jokes < icanhazdadjoke.com >`})

                  .setColor('#2f3136')

                .setDescription(img.attachments[0].text)

            await interaction.reply({ embeds: [embed]})

        }catch(error) {

            console.log(error)

        }

    }

}