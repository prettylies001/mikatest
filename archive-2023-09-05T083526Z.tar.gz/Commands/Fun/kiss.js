const { Client, CommandInteraction, EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle, SlashCommandBuilder } = require("discord.js")

module.exports = {
  data: new SlashCommandBuilder()
  .setName("kiss")
  .setDescription("kisses the mentioned user")
    .addUserOption((option) => 
                  option.setName("user")
                  .setDescription("kiss the mentioned user")
                  .setRequired(true)),
  /**
  *
  * @param {ChatInputCommandInteraction} interaction
  */
  
    /**
     * @param {Client} client
     * @param {CommandInteraction} interaction
     */
    async execute(interaction, client) {

        const user = interaction.options.getUser('user')

        let lista1 = [
            'https://media.tenor.com/IzoHEmuz3u8AAAAd/anime-kiss.gif',
            'https://media.tenor.com/QawhAsgReccAAAAd/anime-kiss.gif',
            'https://media.tenor.com/jSSEC-f_A94AAAAC/anime-kiss.gif',
            'https://media.tenor.com/-OoCr2UG39AAAAAC/kiss-anime.gif',
            'https://imgur.com/82xVqUg.gif'
        ];

        let lista2 = [
            'https://media.tenor.com/KvRTIAp8Dh0AAAAC/anime-kiss.gif',
            'https://media.tenor.com/8mUI_rkXUuAAAAAC/kiss.gif',
            'https://media.tenor.com/ncZ-U5CQbxcAAAAC/kissxsis-kiss.gif',
            'https://static11.hentai-img.com/upload/20210111/687/702509/25.gif',
            'https://aniyuki.com/wp-content/uploads/2021/07/aniyuki-anime-gif-kiss-10.gif'
        ];

        let random1 = lista1[Math.floor(Math.random() * lista1.length)];

        let random2 = lista2[Math.floor(Math.random() * lista2.length)];



        const embed = new EmbedBuilder()
 .setAuthor({

        name: `${interaction.user.username} kissed ${user.username} <33`,

        iconURL: interaction.user.displayAvatarURL({ dynamic: true }),

      })
            

            .setImage(`${random1}`)

          



        let button = new ActionRowBuilder()

            .addComponents(

                new ButtonBuilder()

                    .setCustomId('abracar')

                    .setLabel('kiss back')

                    .setStyle(ButtonStyle.Primary)

                    .setDisabled(false)



            )



        const embed1 = new EmbedBuilder()

        .setAuthor({

        name: `${user.username} kissed ${interaction.user.username}. back hmm!`,

        iconURL: user.displayAvatarURL({ dynamic: true }),

      })
            

         

            .setImage(`${random2}`);



        interaction.reply({ embeds: [embed], components: [button] }).then(() => {



            const filter = i => i.customId === 'abracar' && i.user.id === user.id;

            const collector = interaction.channel.createMessageComponentCollector({ filter, max: 1 });



            collector.on('collect', async i => {



                if (i.customId === 'abracar') {

                    i.reply({ embeds: [embed1] })

                }

            });

        })



    }

}
        