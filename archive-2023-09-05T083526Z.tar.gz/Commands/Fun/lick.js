const { ChatInputCommandInteraction, SlashCommandBuilder, EmbedBuilder } = require("discord.js")
const love = require("discord_love")

module.exports = {
  data: new SlashCommandBuilder()
  .setName("lick")
  .setDescription("licks the mentioned user")
    .addUserOption((option) => 
                  option.setName("user")
                  .setDescription("licks the mentioned user")
                  .setRequired(true)),
  /**
  *
  * @param {ChatInputCommandInteraction} interaction
  */
  execute(interaction) {
    const user = interaction.options.getMember("user")
    const embed = new EmbedBuilder()
    .setTitle("Lick")
    .setDescription(`<@${interaction.user.id}> licked ${user}`)
    .setImage(love.lick())
    interaction.reply({ embeds: [embed]})
  }
}