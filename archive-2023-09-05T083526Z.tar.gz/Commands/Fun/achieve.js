const { ChatInputCommandInteraction, SlashCommandBuilder, EmbedBuilder} = require("discord.js")

module.exports = {
  data: new SlashCommandBuilder()
  .setName("achieve")
  .setDescription("replies with the message in the input as a minecraft achievement")
  .addStringOption((option) => 
                  option.setName("message")
                  .setDescription("message to convert to an achievement")
                  .setRequired(true)),
  /**
  *
  * @param {ChatInputCommandInteraction} interaction
  */
  execute(interaction) {
    const message = interaction.options.getString("message").slice().split(" ")
    const achievement = message.join("+")
    const embed = new EmbedBuilder()
    .setTitle("Achievement")
    .setDescription("wow! what a nice achievement you got there")
    .setImage(`https://minecraftskinstealer.com/achievement/1/Achievement+Get%21/${achievement}`)
    interaction.reply({ embeds: [embed]})
  }
}