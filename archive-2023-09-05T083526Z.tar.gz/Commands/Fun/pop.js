
const { ChatInputCommandInteraction, SlashCommandBuilder, EmbedBuilder, client } = require("discord.js")

module.exports = {
  data: new SlashCommandBuilder()
  .setName("pop")
  .setDescription("Fun with Popping"),
  /**
  *
  * @param {ChatInputCommandInteraction} interactin
*/
  execute(interactin, client) {
 const embed = new EmbedBuilder()
    .setTitle("Pop it")
 .setColor('#2f3136')
    .setDescription(`||pop|| ||pop|| ||pop|| ||pop||
||pop|| ||pop|| ||pop|| ||pop|| 
||pop|| ||pop|| ||pop|| ||pop||
||pop|| ||pop|| ||pop|| ||pop||
||pop|| ||pop|| ||pop|| ||pop||
||pop|| ||pop|| ||pop|| ||pop||
||pop|| ||pop|| ||pop|| ||pop||`) 
.setThumbnail('https://media.tenor.com/_1hMqyFC4LEAAAAC/pop-cat.gif')
    interactin.reply({ embeds: [embed]})
  }
}