const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

module.exports = {

	data: new SlashCommandBuilder()

		.setName('wholesome')

		.setDescription('Wholesome ?'),

	async execute(interaction) {

	const resp = await fetch('https://www.reddit.com/r/wholesomememes/random/.json')

	const list = await resp.json()

	const meme = list[0].data.children[0].data

	const title = meme.title

	const author = meme.author

	const img = meme.url

	const url = `https://reddit.com/${meme.permalink}`

	const comments = meme.num_comments

	const upvotes = meme.ups

	const embed = new EmbedBuilder()

		.setTitle(title)

		.setColor('Random')

		.setImage(img)

		.setURL(url)

		.setTimestamp()

		.setFooter({text: `Meme by: ${author} \t 💬 ${comments} \t ⬆️ ${upvotes}`})

	await interaction.reply({embeds: [embed]})

		},

};