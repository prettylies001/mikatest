const { SlashCommandBuilder } = require('@discordjs/builders');

const { EmbedBuilder } = require('discord.js');

module.exports = {

	data: new SlashCommandBuilder()

        .setName('asknahida')

        .setDescription('have a Question Nahida got you.')

        .addStringOption(option => option.setName('question').setDescription('Enter a question').setRequired(true)),

    async execute(interaction, client, config) {

        let items = ['It is certain.',

            'It is decidedly so.',

            'Without a doubt.',

            'Yes — definitely.',

            'You may rely on it.',

            'As I see it, yes.',

            'Most likely.',

            'Outlook good.',

            'Yes.',

            'Signs point to yes.',

            'Reply hazy, try again.',

            'Ask again later.',

            'Better not tell you now.',

            'Cannot predict now.',

            'Concentrate and ask again.',

            'Dont count on it.',

            'My reply is no.',

            'My sources say no.',

            'Outlook not so good.',

            'Very doubtful.'

        ]

        let special = Math.floor(Math.random() * 1000)

        if (special == 117) {

            var item = "Whatever. All I know you are a good person and I support you ^^"

        } else {

            var item = items[Math.floor(Math.random()*items.length)];

        }

        const string = interaction.options.getString('question');

        const embed = new EmbedBuilder()
.setAuthor({name: "\nNahida: " + item, iconURL: "https://64.media.tumblr.com/ac77a91b7da25b3ab6d233bf6044834d/ca13ceb643e1cad3-28/s400x600/dcbe7ec7bb5bc4e6b3142dcea57562146b17ffca.gif" })
            
            .setDescription("i replied to your question: " + `**${string}**` 
)

        await interaction.reply({embeds: [embed]})

    }

}