const {
    CommandInteraction,
    EmbedBuilder, SlashCommandBuilder,
    ApplicationCommandOptionType,
  } = require("discord.js");
  const superagent = require("superagent");
  
  module.exports = {
  data: new SlashCommandBuilder()
    .setName("twitch")
    .setDescription("Search for Streamers on twitch")
    .addStringOption((option) =>
  option
      .setName("user")
      .setDescription("embed description")
      .setRequired(true)
),
  
    /**
     *
     * @param {CommandInteraction} interaction
     * @param {Client} client
     */
    async execute(interaction) {
      const { options, member } = interaction;
      const channelName = options.getString("user");
  
      interaction.deferReply();
      if (!channelName)
        return interaction.reply({
          content: "Please enter a twitch channel",
          ephermeral: true,
        });
  
      try {
        const Response = await superagent.get(
          `https://api.crunchprank.net/twitch/followcount/${channelName.toLowerCase()}`
        );
        const upTime = await superagent.get(
          `https://api.crunchprank.net/twitch/uptime/${channelName.toLowerCase()}`
        );
        const totalViews = await superagent.get(
          `https://api.crunchprank.net/twitch/total_views/${channelName.toLowerCase()}`
        );
        const accountage = await superagent.get(
          `https://api.crunchprank.net/twitch/creation/${channelName.toLowerCase()}`
        );
        const lastGame = await superagent.get(
          `https://api.crunchprank.net/twitch/game/${channelName.toLowerCase()}`
        );
        const avatarimg = await superagent.get(
          `https://api.crunchprank.net/twitch/avatar/${channelName.toLowerCase()}`
        );
  
        const embed = new EmbedBuilder()
  
          .setColor("#e100ff")
          .setTitle(`Twitch stats for: ${channelName}`)
          .setDescription(
            `❣️ **Followers**: ${Response.text} \n
              👀 **Views**: ${totalViews.text}\n 
              ⬆ **Uptime**: ${upTime.text} \n
              📝 **Created at**: ${accountage.text}  \n
              ⏮️ **Last game played**: ${lastGame.text} \n
              🔴 **Current status**: ${upTime.text}`
          )
          .setFooter({
            text: ` ${member.user.tag}`,
            iconURL: member.user.displayAvatarURL(),
          })
          .setURL(`https://twitch.tv/${channelName}`)
          .setThumbnail("https://emoji.discadia.com/emojis/b297be9a-5537-4f63-aac5-49f20dab935b.gif")
          .setImage(`${avatarimg.text}`)
          .setTimestamp();
  
        interaction.editReply({ embeds: [embed] }).catch((error) => {
          interaction.editReply({
            content: `The user ${channelName} is not a valid user please try again`,
            ephermeral: true,
          });
        });
  
        if (upTime.text === `${channelName} is offline`) {
          upTime.text = "is offline";
        }
      } catch (error) {
        console.error(error);
        return interaction.followUp({
          content:
            "An error has occurred while processing the information, please try again later.",
          ephermeral: true,
        });
      }
    },
  };