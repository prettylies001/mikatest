const {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
} = require("discord.js");
const { searchManga } = require("node-kitsu");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("manga")
    .setDescription("Get info about an Manga.")
    .addStringOption((option) =>
      option
        .setName("title")
        .setDescription("Provide the name of the manga.")
        .setRequired(true)
    ),
  /**
   * @param {ChatInputCommandInteraction} interaction
   */
  execute(interaction) {
    const { options } = interaction;
    const title = options.getString("title");
    const embed = new EmbedBuilder()
    .setColor("Blurple")
    .setTimestamp();

    searchManga(title, 0)
      .then((result) => {
        const manga = result[0];
        const status = manga.attributes.status
          .replace("finished", "Finished")
          .replace("ongoing", "Ongoing")
          .replace("current", "Currently Airing");

        if (!manga.attributes.averageRating) {
          embed.addFields({ name: "Rating", value: `No ratings yet.` });
        } else {
          embed.addFields({
            name: "Rating",
            value: `${manga.attributes.averageRating}`,
            inline: true,
          });
        }

        if (!manga.attributes.titles.en_us)
          embed.setTitle(`${manga.attributes.titles.en_jp}`);
        else {
          embed.setTitle(`${manga.attributes.titles.en_us}`);
        }

        return interaction.reply({
          embeds: [
            embed
              .setImage(manga.attributes.posterImage.original)
             .setDescription(manga.attributes.synopsis)
              .addFields([
                {
                  name: "Premiered on",
                  value: manga.attributes.createdAt,
                  inline: true,
                },
                {
                  name: "Japanese Title",
                  value: `${manga.attributes.titles.en_jp}` || "Unknown.",
                  inline: true,
                },
                {
                  name: "Status",
                  value: status,
                  inline: true,
                },
              ]),
          ],
        });
      })
      .catch(() => {
        return interaction.reply({
          embeds: [embed.setDescription("No results found.")],
        });
      });
  },
};
