const {

  ChatInputCommandInteraction,

  SlashCommandBuilder,

  EmbedBuilder,

  ActionRowBuilder,

  ButtonBuilder

} = require('discord.js');

module.exports = {

  

  data: new SlashCommandBuilder()

  .setName('coinflip')

  .setDescription('Flips a coin!'),

  /**

  * @param {ChatInputCommandInteraction} interaction

  *

  */

  async execute(interaction) {

    const {

      channel,

      member

    } = interaction;

    var num = 0

    

    const resultTimer = 1000 * 3; //the "3" represent 3 seconds. change it to change flipping coin duration.

    const side = ["Heads",

      "Tails"];

    const R = new ActionRowBuilder()

    .addComponents(

      new ButtonBuilder()

      .setLabel("Flip the Coin")

      .setStyle("Success")

      .setCustomId("isFlip")

    );

    const Rs = new ActionRowBuilder()

    .addComponents(

      new ButtonBuilder()

      .setLabel("Re-flip the Coin")

      .setStyle("Success")

      .setCustomId("isReflip")

    );

    interaction.deferUpdate;

    let sent = await interaction.reply({

      embeds: [

        new EmbedBuilder()

        .setColor('#2f3136')

        .setTitle('CoinFlips')

        .setDescription('Click the button below to flip the coins!')

        .setTimestamp()

      ],

      components: [R],

      fetchReply: true

    });

    let collector = sent.createMessageComponentCollector({

      time: 1000 * 60 * 10,

    });

    collector.on("collect", async interaction => {

      if (interaction.user.id !== member.id) return interaction.reply({

        content: "You are not the user that run the commands!",

        ephemeral: true

      });

      if (interaction.customId == "isFlip") {

        const sides = side[Math.floor(Math.random()*side.length)];

        interaction.deferUpdate;

        await interaction.update({

          embeds: [

            new EmbedBuilder()

            .setColor("#2f3136")

            .setTitle('CoinFlips')

            .setDescription(`**Flipping the Coins...**`)

            .setTimestamp()

          ],

          components: []

        });

        setTimeout(async () => {

          await interaction.message.edit({

            embeds: [

              new EmbedBuilder()

              .setColor("#2f3136")

              .setTitle('CoinFlips')

              .setDescription(`You Flipped the Coins and got ***${sides}***`)

              .setTimestamp()

            ],

            components: [Rs]

          });

        }, resultTimer);

      } else if (interaction.customId == "isReflip") {

        let sides = side[Math.floor(Math.random()*side.length)];

        await interaction.update({

          embeds: [

            new EmbedBuilder()

            .setColor("#FF84C0")

            .setTitle('CoinFlips')

            .setDescription(`**Re-Flipping the Coins...**`)

            .setTimestamp()

          ],

          components: []

        });

        num++

        const messages = interaction.message;

        messages.embeds.forEach(async (embed) => {

          sides == "Heads" ? sides = true: sides = false;

          let text;

          embed.description.toLowerCase().includes('heads') == true ? text = true: text = false;

          interaction.deferUpdate;

          if (text == true && sides == true) {

            interaction.deferUpdate;

            return setTimeout(async () => {

              await interaction.message.edit({

                embeds: [

                  new EmbedBuilder()

                  .setColor("#FF84C0")

                  .setTitle('CoinFlips')

                  .setDescription(`You Re-Flipped the Coins ${num + " times"} and got ***Heads Again***`)

                  .setTimestamp()

                ],

                components: [Rs]

              });

            }, resultTimer);

          } else if (text == false && sides == false) {

            interaction.deferUpdate;

            return setTimeout(async () => {

              await interaction.message.edit({

                embeds: [

                  new EmbedBuilder()

                  .setColor("#FF84C0")

                  .setTitle('CoinFlips')

                  .setDescription(`You Re-Flipped the Coins ${num + " times"} and got ***Tails Again***`)

                  .setTimestamp()

                ],

                components: [Rs]

              });

            }, resultTimer);

          } else {

            interaction.deferUpdate;

            await interaction.message.edit({

              embeds: [

                new EmbedBuilder()

                .setColor("#FF84C0")

                .setTitle('CoinFlips')

                .setDescription(`You Re-Flipped the Coins ${num + " times"} and got ***${sides == true ? "Heads": "Tails"}***`)

                .setTimestamp()

              ],

              components: [Rs]

            });

          }

        });

      }

    });

  }

}